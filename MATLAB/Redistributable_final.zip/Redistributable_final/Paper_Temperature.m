%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in March/April 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
addpath('GISTEMP');
addpath('Opt');
addpath('Agency');


% Load temperature data and inventory
GIS_station_inv = load_GISTEMP_inventory('GISTEMP/gistemp1.0/tmp/input/v3.inv');
step2_data = load_GISTEMP_step2_v3('GISTEMP/gistemp1.0/tmp/work/step2.v3');
step3_data = load_GISTEMP_step3_v3('GISTEMP/gistemp1.0/tmp/work/step3.v3'); %anomalies not averages
GIS_ghcnm = load_GISTEMP_ghcnm_qca_dat('GISTEMP/gistemp1.0/tmp/input/ghcnm.tavg.qca.dat');
[GIS_antarc_data, GIS_antarc_inv] = load_GISTEMP_antarc('GISTEMP/gistemp1.0/tmp/input/');


% Merge ghcnm and antartic inventory 
inventory.ids = [GIS_station_inv.ids, GIS_antarc_inv.ids];
inventory.names = [GIS_station_inv.names, GIS_antarc_inv.names];
inventory.lats = [GIS_station_inv.lats, GIS_antarc_inv.lats];
inventory.longs = [GIS_station_inv.longs, GIS_antarc_inv.longs];


% Raw data - no adjustment or omission of data 
%  The data used here is the merged temperature data, namely:
%  input/antarc[1,2,3].[txt,list] and ghcnm.tavg.qca.dat
raw_data.ids = [GIS_ghcnm.ids, GIS_antarc_data.ids];
raw_data.years = [GIS_ghcnm.years, GIS_antarc_data.years];
raw_data.monthly_avg = [GIS_ghcnm.monthly_avg, GIS_antarc_data.monthly_avg];
raw_data.yearly_avg = [GIS_ghcnm.yearly_avg, GIS_antarc_data.yearly_avg];
    

% Merge inventory and temperature data structs
merged_ghcnm_data_inv = merge_GISTEMP_inv_data(inventory, raw_data); % raw data
merged_step2_data_inv = merge_GISTEMP_inv_data(inventory, step2_data); % preprocessed


% Load Gridded Ocean SST data
sbbx_ersst = load_SBBX_ERSST(); % anomaly data over the grid - assume 1951-1980 reference period

% Load raw ERSST data
%raw_ersst = load_ersst(); 

%
start_year     = 1950;%1880;
end_year       = 2016;
n_years        = end_year - start_year + 1;

ref_start_year = 1951;
ref_end_year   = 1980;

%months = {'Jan'; 'Feb'; 'Mar'; 'Apr'; 'May'; 'Jun'; 'Jul'; 'Aug'; 'Sep'; 'Oct'; 'Nov'; 'Dec'};


output_path = 'Data/';


%% 3 - Run optimization for V_{spherical harmonics} at yearly resolution 
%      using preprocessed grid data (land-only) and gridded sst data

    % use step3.v3 data - comes as anomalies at grid centers
    % use SBBX.ERSSTv4 data - comes as anomalies at grid centers
    % run optimization

    local_path = [output_path, 'opt_sh_yearly_grid_with_sst_', ...
                  num2str(start_year), '-', num2str(end_year), '/'];

    diary([local_path, 'opt_sh_yearly_grid_with_sst.txt']);
    for L=[3,6,9]
        disp(['L = ', num2str(L)]);
        t = tic;
        opt_sh_yearly_grid_with_sst = cell(n_years,1);
        idx = 1;
        month = -1;
        for year=start_year:end_year
            valid_stations = find_GISTEMP_valid_cells(step3_data, month, year);
            valid_ssts = find_GISTEMP_valid_ssts(sbbx_ersst, month, year);
            valid_merged = merge_GISTEMP_station_sst(valid_stations, valid_ssts);
            % latitude is in [-90, 90] and longitude is in [-180, 180]
            if isempty(valid_merged)
                continue;
            end
            [res.a, res.mu, res.val, res.sval, res.scale, res.M, res.lats, ...
                res.longs] = sh_gistemp_locs(valid_merged, month, L);
            res.year = year;
            res.month = -1;

            disp([num2str(year), ': mu = ', num2str(res.mu)]);
            disp(['   global temp = ', num2str(res.val)]);
            disp(['   global temp (scaled) = ', num2str(res.sval)]);
            save([local_path, 'opt_sh_yearly_grid_with_sst/opt_', ...
                  num2str(year), '_L=', num2str(L), '.mat'], 'res');

            opt_sh_yearly_grid_with_sst{idx} = res;

            idx = idx + 1;
        end
        
        % the input data was already anomalies
        idx = 1;
        for year=start_year:end_year
            opt_sh_yearly_grid_with_sst{idx}.ref_mean = -9999; 
            opt_sh_yearly_grid_with_sst{idx}.sref_mean = -9999;
            opt_sh_yearly_grid_with_sst{idx}.anom = opt_sh_yearly_grid_with_sst{idx}.val;
            opt_sh_yearly_grid_with_sst{idx}.sanom = opt_sh_yearly_grid_with_sst{idx}.sval;
            idx = idx + 1;
        end

        save([local_path, 'opt_sh_yearly_grid_with_sst_L=', num2str(L), '.mat'], ...
                                    'opt_sh_yearly_grid_with_sst', ...
                                    'start_year', ...
                                    'end_year', ...
                                    'ref_start_year', ...
                                    'ref_end_year');
        toc(t);
    end
    diary off;
    
    
   
    
    
%% 3 - Run optimization for V_{spherical harmonics} at yearly resolution using GISTEMP preprocessed land-only data and gridded sst data

    % use use step2.v3 data - convert to anomalies prior to use
    % use SBBX.ERSSTv4 data - comes as anomalies at grid centers
    % run optimization

    % convert the valid_station temperatures to anomalies - removes monthly data
    merged_step2_data_inv_anoms = convert_ghcnm_to_anom(merged_step2_data_inv, ref_start_year, ref_end_year);

    local_path = [output_path, 'opt_sh_yearly_GISTEMP_anom_with_sst_', ...
                  num2str(start_year), '-', num2str(end_year), '/'];

    diary([local_path, 'opt_sh_yearly_GISTEMP_anom_with_sst.txt']);
    for L=[3,6,9]
        disp(['L = ', num2str(L)]);
        t = tic;
        opt_sh_yearly_GISTEMP_anom_with_sst = cell(n_years,1);
        idx = 1;
        month = -1;
        for year=start_year:end_year
            valid_stations = find_GISTEMP_valid_stations(merged_step2_data_inv_anoms, month, year);
            valid_ssts = find_GISTEMP_valid_ssts(sbbx_ersst, month, year);
            valid_merged = merge_GISTEMP_station_sst(valid_stations, valid_ssts);
            % latitude is in [-90, 90] and longitude is in [-180, 180]
            if isempty(valid_merged)
                continue;
            end
            [res.a, res.mu, res.val, res.sval, res.scale, res.M, res.lats, res.longs] = sh_gistemp_locs(valid_merged, month, L);
            res.year = year;
            res.month = -1;

            disp([num2str(year), ': mu = ', num2str(res.mu)]);
            disp(['   global temp = ', num2str(res.val)]);
            disp(['   global temp (scaled) = ', num2str(res.sval)]);
            save([local_path, 'opt_sh_yearly_GISTEMP_anom_with_sst/opt_', num2str(year), '_L=', num2str(L), '.mat'], 'res');

            opt_sh_yearly_GISTEMP_anom_with_sst{idx} = res;

            idx = idx + 1;
        end
        
        % the input data was already anomalies
        idx = 1;
        for year=start_year:end_year
            opt_sh_yearly_GISTEMP_anom_with_sst{idx}.ref_mean = -9999; %unknown
            opt_sh_yearly_GISTEMP_anom_with_sst{idx}.sref_mean = -9999; %unknown
            opt_sh_yearly_GISTEMP_anom_with_sst{idx}.anom = opt_sh_yearly_GISTEMP_anom_with_sst{idx}.val;
            opt_sh_yearly_GISTEMP_anom_with_sst{idx}.sanom = opt_sh_yearly_GISTEMP_anom_with_sst{idx}.sval;
            idx = idx + 1;
        end

        save([local_path, 'opt_sh_yearly_GISTEMP_anom_with_sst_L=', num2str(L), '.mat'], ...
                                    'opt_sh_yearly_GISTEMP_anom_with_sst', ...
                                    'start_year', ...
                                    'end_year', ...
                                    'ref_start_year', ...
                                    'ref_end_year');
        toc(t);
    end
    diary off;
    
    
   
    
    
%% 4 - Run optimization for V_{piecewise constant} at yearly resolution using GISTEMP preprocessed grid data (land-only) and gridded sst data - fine grid

    % use step3.v3 data - comes as anomalies at grid centers
    % use SBBX.ERSSTv4 data - comes as anomalies at grid centers
    % run optimization 

    local_path = [output_path, 'opt_pwc_yearly_grid_with_sst_fine_', ...
                  num2str(start_year), '-', num2str(end_year), '/'];

    use_fine_grid = true;
    diary([local_path, 'opt_pwc_yearly_grid_with_sst_fine.txt']);
    t = tic;
    opt_pwc_yearly_grid_with_sst_fine = cell(n_years,1);
    idx = 1;
    month = -1;
    for year=start_year:end_year
        valid_stations = find_GISTEMP_valid_cells(step3_data, month, year);
        valid_ssts = find_GISTEMP_valid_ssts(sbbx_ersst, month, year);
        valid_merged = merge_GISTEMP_station_sst(valid_stations, valid_ssts);
        % latitude is in [-90, 90] and longitude is in [-180, 180]
        if isempty(valid_merged)
            continue;
        end
        [res.a, res.mu, res.val, res.sval, res.scale, res.M, res.lats, res.longs, res.num_empty_boxes] = grid_gistemp_pwc(valid_merged, use_fine_grid);
        res.year = year;
        res.month = -1;

        disp([num2str(year), ': mu = ', num2str(res.mu)]);
        disp(['   global temp = ', num2str(res.val)]);
        disp(['   global temp (scaled) = ', num2str(res.sval)]);
        disp(['   # of empty grid boxes = ', num2str(res.num_empty_boxes)]);
        save([local_path, 'opt_pwc_yearly_grid_with_sst_fine/opt_', num2str(year), '.mat'], 'res');

        opt_pwc_yearly_grid_with_sst_fine{idx} = res;

        idx = idx + 1;
    end
    % find reference period mean
    s_idx = ref_start_year - start_year + 1;
    e_idx = ref_end_year - start_year + 1;
    ref_mean = 0;
    sref_mean = 0;
    for i = s_idx:e_idx
        ref_mean = ref_mean + opt_pwc_yearly_grid_with_sst_fine{i}.val; 
        sref_mean = sref_mean + opt_pwc_yearly_grid_with_sst_fine{i}.sval;
    end
    ref_mean = ref_mean / (e_idx - s_idx + 1);
    sref_mean = sref_mean / (e_idx - s_idx + 1);
    % convert values to anomalies from the reference period
    idx = 1;
    for year=start_year:end_year
        opt_pwc_yearly_grid_with_sst_fine{idx}.ref_mean = ref_mean;
        opt_pwc_yearly_grid_with_sst_fine{idx}.sref_mean = sref_mean;
        opt_pwc_yearly_grid_with_sst_fine{idx}.anom = opt_pwc_yearly_grid_with_sst_fine{idx}.val - ref_mean;
        opt_pwc_yearly_grid_with_sst_fine{idx}.sanom = opt_pwc_yearly_grid_with_sst_fine{idx}.sval - sref_mean;
        idx = idx + 1;
    end
   
    
    save([local_path, 'opt_pwc_yearly_grid_with_sst_fine.mat'], ...
                                'opt_pwc_yearly_grid_with_sst_fine', ...
                                'start_year', ...
                                'end_year', ...
                                'ref_start_year', ...
                                'ref_end_year');
    toc(t);
    diary off;

%% 4 - Run optimization for V_{piecewise constant} at yearly resolution using GISTEMP preprocessed grid data (land-only) and gridded sst data - coarse grid

    % use step3.v3 data - comes as anomalies at grid centers
    % use SBBX.ERSSTv4 data - comes as anomalies at grid centers
    % run optimization 

    local_path = [output_path, 'opt_pwc_yearly_grid_with_sst_coarse_', ...
                  num2str(start_year), '-', num2str(end_year), '/'];

    use_fine_grid = false;
    diary([local_path, 'opt_pwc_yearly_grid_with_sst_coarse.txt']);
    t = tic;
    opt_pwc_yearly_grid_with_sst_coarse = cell(n_years,1);
    idx = 1;
    month = -1;
    for year=start_year:end_year
        valid_stations = find_GISTEMP_valid_cells(step3_data, month, year);
        valid_ssts = find_GISTEMP_valid_ssts(sbbx_ersst, month, year);
        valid_merged = merge_GISTEMP_station_sst(valid_stations, valid_ssts);
        % latitude is in [-90, 90] and longitude is in [-180, 180]
        if isempty(valid_merged)
            continue;
        end
        [res.a, res.mu, res.val, res.sval, res.scale, res.M, res.lats, res.longs, res.num_empty_boxes] = grid_gistemp_pwc(valid_merged, use_fine_grid);
        res.year = year;
        res.month = -1;

        disp([num2str(year), ': mu = ', num2str(res.mu)]);
        disp(['   global temp = ', num2str(res.val)]);
        disp(['   global temp (scaled) = ', num2str(res.sval)]);
        disp(['   # of empty grid boxes = ', num2str(res.num_empty_boxes)]);
        save([local_path, 'opt_pwc_yearly_grid_with_sst_coarse/opt_', num2str(year), '.mat'], 'res');

        opt_pwc_yearly_grid_with_sst_coarse{idx} = res;

        idx = idx + 1;
    end
    % find reference period mean
    s_idx = ref_start_year - start_year + 1;
    e_idx = ref_end_year - start_year + 1;
    ref_mean = 0;
    sref_mean = 0;
    for i = s_idx:e_idx
        ref_mean = ref_mean + opt_pwc_yearly_grid_with_sst_coarse{i}.val; 
        sref_mean = sref_mean + opt_pwc_yearly_grid_with_sst_coarse{i}.sval;
    end
    ref_mean = ref_mean / (e_idx - s_idx + 1);
    sref_mean = sref_mean / (e_idx - s_idx + 1);
    % convert values to anomalies from the reference period
    idx = 1;
    for year=start_year:end_year
        opt_pwc_yearly_grid_with_sst_coarse{idx}.ref_mean = ref_mean;
        opt_pwc_yearly_grid_with_sst_coarse{idx}.sref_mean = sref_mean;
        opt_pwc_yearly_grid_with_sst_coarse{idx}.anom = opt_pwc_yearly_grid_with_sst_coarse{idx}.val - ref_mean;
        opt_pwc_yearly_grid_with_sst_coarse{idx}.sanom = opt_pwc_yearly_grid_with_sst_coarse{idx}.sval - sref_mean;
        idx = idx + 1;
    end
   
    
    save([local_path, 'opt_pwc_yearly_grid_with_sst_coarse.mat'], ...
                                'opt_pwc_yearly_grid_with_sst_coarse', ...
                                'start_year', ...
                                'end_year', ...
                                'ref_start_year', ...
                                'ref_end_year');
    toc(t);
    diary off;

   
    
  
    
    
    
%% 4 - Run optimization for V_{piecewise constant} at yearly resolution using GISTEMP preprocessed land-only data (land-only) and gridded sst data - fine grid

    % use use step2.v3 data - convert to anomalies prior to use
    % use SBBX.ERSSTv4 data - comes as anomalies at grid centers
    % run optimization 

    % convert the valid_station temperatures to anomalies - removes monthly data
    merged_step2_data_inv_anoms = convert_ghcnm_to_anom(merged_step2_data_inv, ref_start_year, ref_end_year);

    local_path = [output_path, 'opt_pwc_yearly_GISTEMP_anom_with_sst_fine_', ...
                num2str(start_year), '-', num2str(end_year), '/'];

    use_fine_grid = true;
    diary([local_path, 'opt_pwc_yearly_GISTEMP_anom_with_sst_fine.txt']);
    t = tic;
    opt_pwc_yearly_GISTEMP_anom_with_sst_fine = cell(n_years,1);
    idx = 1;
    month = -1;
    for year=start_year:end_year
        valid_stations = find_GISTEMP_valid_stations(merged_step2_data_inv_anoms, month, year);
        valid_ssts = find_GISTEMP_valid_ssts(sbbx_ersst, month, year);
        valid_merged = merge_GISTEMP_station_sst(valid_stations, valid_ssts);
        % latitude is in [-90, 90] and longitude is in [-180, 180]
        if isempty(valid_merged)
            continue;
        end
        [res.a, res.mu, res.val, res.sval, res.scale, res.M, res.lats, res.longs, res.num_empty_boxes] = grid_gistemp_pwc(valid_merged, use_fine_grid);
        res.year = year;
        res.month = -1;

        disp([num2str(year), ': mu = ', num2str(res.mu)]);
        disp(['   global temp = ', num2str(res.val)]);
        disp(['   global temp (scaled) = ', num2str(res.sval)]);
        disp(['   # of empty grid boxes = ', num2str(res.num_empty_boxes)]);
        save([local_path, 'opt_pwc_yearly_GISTEMP_anom_with_sst_fine/opt_', num2str(year), '.mat'], 'res');

        opt_pwc_yearly_GISTEMP_anom_with_sst_fine{idx} = res;

        idx = idx + 1;
    end
    % find reference period mean
    s_idx = ref_start_year - start_year + 1;
    e_idx = ref_end_year - start_year + 1;
    ref_mean = 0;
    sref_mean = 0;
    for i = s_idx:e_idx
        ref_mean = ref_mean + opt_pwc_yearly_GISTEMP_anom_with_sst_fine{i}.val; 
        sref_mean = sref_mean + opt_pwc_yearly_GISTEMP_anom_with_sst_fine{i}.sval;
    end
    ref_mean = ref_mean / (e_idx - s_idx + 1);
    sref_mean = sref_mean / (e_idx - s_idx + 1);
    % convert values to anomalies from the reference period
    idx = 1;
    for year=start_year:end_year
        opt_pwc_yearly_GISTEMP_anom_with_sst_fine{idx}.ref_mean = ref_mean;
        opt_pwc_yearly_GISTEMP_anom_with_sst_fine{idx}.sref_mean = sref_mean;
        opt_pwc_yearly_GISTEMP_anom_with_sst_fine{idx}.anom = opt_pwc_yearly_GISTEMP_anom_with_sst_fine{idx}.val - ref_mean;
        opt_pwc_yearly_GISTEMP_anom_with_sst_fine{idx}.sanom = opt_pwc_yearly_GISTEMP_anom_with_sst_fine{idx}.sval - sref_mean;
        idx = idx + 1;
    end
   
    
    save([local_path, 'opt_pwc_yearly_GISTEMP_anom_with_sst_fine.mat'], ...
                                'opt_pwc_yearly_GISTEMP_anom_with_sst_fine', ...
                                'start_year', ...
                                'end_year', ...
                                'ref_start_year', ...
                                'ref_end_year');
    toc(t);
    diary off;

    
    
%% 4 - Run optimization for V_{piecewise constant} at yearly resolution using GISTEMP preprocessed land-only data (land-only) and gridded sst data - coarse grid

    % use use step2.v3 data - convert to anomalies prior to use
    % use SBBX.ERSSTv4 data - comes as anomalies at grid centers
    % run optimization 

    % convert the valid_station temperatures to anomalies - removes monthly data
    merged_step2_data_inv_anoms = convert_ghcnm_to_anom(merged_step2_data_inv, ref_start_year, ref_end_year);

    local_path = [output_path, 'opt_pwc_yearly_GISTEMP_anom_with_sst_coarse_', ...
                  num2str(start_year), '-', num2str(end_year), '/'];

    use_fine_grid = false;
    diary([local_path, 'opt_pwc_yearly_GISTEMP_anom_with_sst_coarse.txt']);
    t = tic;
    opt_pwc_yearly_GISTEMP_anom_with_sst_coarse = cell(n_years,1);
    idx = 1;
    month = -1;
    for year=start_year:end_year
        valid_stations = find_GISTEMP_valid_stations(merged_step2_data_inv_anoms, month, year);
        valid_ssts = find_GISTEMP_valid_ssts(sbbx_ersst, month, year);
        valid_merged = merge_GISTEMP_station_sst(valid_stations, valid_ssts);
        % latitude is in [-90, 90] and longitude is in [-180, 180]
        if isempty(valid_merged)
            continue;
        end
        [res.a, res.mu, res.val, res.sval, res.scale, res.M, res.lats, res.longs, res.num_empty_boxes] = grid_gistemp_pwc(valid_merged, use_fine_grid);
        res.year = year;
        res.month = -1;

        disp([num2str(year), ': mu = ', num2str(res.mu)]);
        disp(['   global temp = ', num2str(res.val)]);
        disp(['   global temp (scaled) = ', num2str(res.sval)]);
        disp(['   # of empty grid boxes = ', num2str(res.num_empty_boxes)]);
        save([local_path, 'opt_pwc_yearly_GISTEMP_anom_with_sst_coarse/opt_', num2str(year), '.mat'], 'res');

        opt_pwc_yearly_GISTEMP_anom_with_sst_coarse{idx} = res;

        idx = idx + 1;
    end
    % find reference period mean
    s_idx = ref_start_year - start_year + 1;
    e_idx = ref_end_year - start_year + 1;
    ref_mean = 0;
    sref_mean = 0;
    for i = s_idx:e_idx
        ref_mean = ref_mean + opt_pwc_yearly_GISTEMP_anom_with_sst_coarse{i}.val; 
        sref_mean = sref_mean + opt_pwc_yearly_GISTEMP_anom_with_sst_coarse{i}.sval;
    end
    ref_mean = ref_mean / (e_idx - s_idx + 1);
    sref_mean = sref_mean / (e_idx - s_idx + 1);
    % convert values to anomalies from the reference period
    idx = 1;
    for year=start_year:end_year
        opt_pwc_yearly_GISTEMP_anom_with_sst_coarse{idx}.ref_mean = ref_mean;
        opt_pwc_yearly_GISTEMP_anom_with_sst_coarse{idx}.sref_mean = sref_mean;
        opt_pwc_yearly_GISTEMP_anom_with_sst_coarse{idx}.anom = opt_pwc_yearly_GISTEMP_anom_with_sst_coarse{idx}.val - ref_mean;
        opt_pwc_yearly_GISTEMP_anom_with_sst_coarse{idx}.sanom = opt_pwc_yearly_GISTEMP_anom_with_sst_coarse{idx}.sval - sref_mean;
        idx = idx + 1;
    end
   
    
    save([local_path, 'opt_pwc_yearly_GISTEMP_anom_with_sst_coarse.mat'], ...
                                'opt_pwc_yearly_GISTEMP_anom_with_sst_coarse', ...
                                'start_year', ...
                                'end_year', ...
                                'ref_start_year', ...
                                'ref_end_year');
    toc(t);
    diary off;
