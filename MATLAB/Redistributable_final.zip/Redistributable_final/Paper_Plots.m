%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in March/April 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% This function loads the input and optimization output files in order to
% generate all of the plots from the papers.  See the comments below for
% required input files.
function Paper_Plots()

    addpath('GISTEMP');
    addpath('Opt');
    addpath('Agency');

    noaa_land_only = noaa_annual_anomalies_land_only(); % 1901 - 2000 - shifted to 1951 - 1980
    noaa_land_ocean = noaa_annual_anomalies_land_ocean(); % 1901 - 2000 - shifted to 1951 - 1980
    land_boxes = load_gistemp_land_boxes('GISTEMP/gistemp1.0/tmp/result/GHCNv3BoxesLand.1200.txt'); % 1951 - 1980
    GIS_yearly_land_boxes = compute_yearly_box_avg(land_boxes);
    GIS_yearly_land_ocean_temps = load_GISTEMP_global_land_ocean_anomalies('GISTEMP/gistemp1.0/tmp/result/mixedGLB.Ts.ERSSTV4.GHCN.CL.PA.txt'); % 1951 - 1980

    path = 'Data/';

    % files = [{<Path String>;
    %           <struct name>; 
    %           <filename suffix and extension>
    %           <substruct name - if any>
    %           <plot title>
    %           <true = land-only, false = land-ocean>
    %           <Temperature or Anomaly data string>
    %           <plot start year>
    %           <plot end year>
    %           <data base year>
    %           <bool - true reshifts data to 1951-1980 reference period>
    %           <anomaly plot y limit lower bound>
    %           <anomaly plot y limit upper bound>
    %         }, ... ];
    
    
    files = {};
     files = [files, {'opt_sh_yearly_grid_with_sst_1950-2016/'; 'opt_sh_yearly_grid_with_sst'; '.mat'; ''; 'GISTEMP Processed Grid, Land + Ocean'; false; 'Anomalies'; 1950; 2016; 1950; true; -0.6; 1.4}];
     files = [files, {'opt_sh_yearly_GISTEMP_anom_with_sst_1950-2016/'; 'opt_sh_yearly_GISTEMP_anom_with_sst'; '.mat'; ''; 'GISTEMP Processed, Land-Only + NOAA ERSST, Land + Ocean'; false; 'Temperature'; 1950; 2016; 1950; true; -0.6; 1.4}];

    for f_idx=1:size(files,2)

        % Get the range of years to be plotted
        start_year = files{8, f_idx}; 
        end_year = files{9, f_idx}; 
        n_years = end_year - start_year + 1;

        % Get the subset of each reference data set for the year range
        % NOTE: There is an assumed base year for these data sets
        noaa_land_sub = noaa_land_only(2, (start_year - 1880 + 1):(end_year - 1880 + 1));
        noaa_land_ocean_sub = noaa_land_ocean(2, (start_year - 1880 + 1):(end_year - 1880 + 1));
        nasa_land_sub = GIS_yearly_land_boxes.global_avg((start_year - 1880 + 1):(end_year - 1880 + 1))';
        nasa_land_ocean_sub = GIS_yearly_land_ocean_temps.global_avg((start_year - GIS_yearly_land_ocean_temps.first_year + 1):(end_year - GIS_yearly_land_ocean_temps.first_year + 1));

        for L=[3,6,9]

            % Load the data set 
            data = load([path, files{1, f_idx}, files{2, f_idx}, '_L=', num2str(L), files{3, f_idx}]);

            yearly_mu = zeros(n_years, 1);
            yearly_temps = zeros(n_years, 1);
            yearly_anoms = zeros(n_years, 1);
            
            % Get the mu, temperature and anomaly for each year
            for i=1:n_years

                var = ['data.', files{4, f_idx}, files{2, f_idx}, '{start_year - files{10, f_idx} + i}'];
                eval(['yearly_mu(i) = ',    var, '.mu / ' var '.scale;']);
                eval(['yearly_temps(i) = ', var, '.sval;']);
                eval(['yearly_anoms(i) = ', var, '.sanom;']);

            end
            
            % Check if we are shifting the reference period
            if files{11, f_idx} 
                % shift the mean to the specified reference period
                start_ref_idx = 1951 - start_year + 1;
                end_ref_idx = 1980 - start_year + 1;
                m = mean(yearly_temps(start_ref_idx:end_ref_idx));
                yearly_anoms = yearly_temps - m;
            end
            
            f = figure;
            set(f, 'position', [100, 500, 1024, 768]);
            hold on;
            % mu values
            plot(start_year:end_year, yearly_mu, 'LineWidth', 4);
            title(['\fontsize{12}', files{5, f_idx}, ', L = ', num2str(L), ', ', num2str(start_year), ' - ', num2str(end_year), ': \mu']);
            leg = legend({['\mu, L = ', num2str(L)]}, 'Location', 'southeast');
            leg.FontSize = 12;
            box on;
            hold off;
            saveas(f, [path, files{2, f_idx}, '_', num2str(files{8, f_idx}), '-', num2str(files{9, f_idx}), '/', files{2, f_idx}, '_L=', num2str(L), '_mu.png']);
            close(f);
            
            f = figure;
            set(f, 'position', [100, 500, 1024, 768]);
            hold on;
            % temperature values
            plot(start_year:end_year, yearly_temps, 'LineWidth', 4);
            title(['\fontsize{12}', files{5, f_idx}, ', L = ', num2str(L), ', ', num2str(start_year), ' - ', num2str(end_year), ': ', files{7, f_idx}]);
            leg = legend({['SH: L = ', num2str(L)]}, 'Location', 'southeast');
            leg.FontSize = 12;
            box on;
            hold off;
            saveas(f, [path, files{2, f_idx}, '_', num2str(files{8, f_idx}), '-', num2str(files{9, f_idx}), '/', files{2, f_idx}, '_L=', num2str(L), '.png']);
            close(f);

            f = figure;
            set(f, 'position', [100, 500, 1024, 768]);
            hold on;
            % anomaly values
            plot(start_year:end_year, yearly_anoms, 'LineWidth', 4);
            if files{6, f_idx}
                % NOAA land-only values
                plot(start_year:end_year, noaa_land_sub, 'LineWidth', 4);
                % NASA / GISS land-only values
                plot(start_year:end_year, nasa_land_sub, 'LineWidth', 4);
                %title(['\fontsize{12}', files{5, f_idx}, ', L = ', num2str(L), ', ', num2str(start_year), ' - ', num2str(end_year), ': Anomalies']);
                %leg = legend({['SH: L = ', num2str(L)], 'NOAA Land-only', 'NASA-GIS Land-only'}, 'Location', 'southeast');
                leg = legend({['SH', num2str(L)], 'NOAA', 'GISTEMP'}, 'Location', 'southeast');
                leg.FontSize = 12;
            else
                % NOAA land-only values
                plot(start_year:end_year, noaa_land_ocean_sub, 'LineWidth', 4);
                % NASA / GISS land-only values
                plot(start_year:end_year, nasa_land_ocean_sub, 'LineWidth', 4);
                %title(['\fontsize{12}', files{5, f_idx}, ', L = ', num2str(L), ', ', num2str(start_year), ' - ', num2str(end_year), ': Anomalies']);
                %leg = legend({['SH: L = ', num2str(L)], 'NOAA Land + Ocean', 'NASA-GIS Land + Ocean'}, 'Location', 'southeast');
                leg = legend({['SH', num2str(L)], 'NOAA', 'GISTEMP'}, 'Location', 'southeast');
                leg.FontSize = 12;
            end
            if files{12,f_idx} ~= -9999
                ylim([files{12, f_idx}, files{13, f_idx}]);
            end
            box on;
            hold off;
            if files{6, f_idx}
                saveas(f, [path, files{2, f_idx}, '_', num2str(files{8, f_idx}), '-', num2str(files{9, f_idx}), '/', files{2, f_idx}, '_Agency_TempAnom_land_only_L=', num2str(L), '.png']);
            else
                saveas(f, [path, files{2, f_idx}, '_', num2str(files{8, f_idx}), '-', num2str(files{9, f_idx}), '/', files{2, f_idx}, '_Agency_TempAnom_land_ocean_L=', num2str(L), '.png']);
            end
            close(f);
        end
    end
    
    
    
    
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    % files = [{<Path String>;
    %           <struct name>; 
    %           <filename suffix and extension>
    %           <substruct name - if any>
    %           <plot title>
    %           <true = land-only, false = land-ocean>
    %           <Temperature or Anomaly data string>
    %           <plot start year>
    %           <plot end year>
    %           <data base year>
    %           <bool - true reshifts data to 1951-1980 reference period>
    %           <anomaly plot y limit lower bound>
    %           <anomaly plot y limit upper bound>
    %           <string - fine or coarse for legend labels>
    %         }, ... ];

    
    files = {};
    
    files = [files, {'opt_pwc_yearly_grid_with_sst_fine_1950-2016/'; 'opt_pwc_yearly_grid_with_sst_fine'; '.mat'; ''; 'GISTEMP Processed Grid, Land-Ocean'; false; 'Anomalies'; 1950; 2016; 1950; true; -9999; -9999; 'PCF'}];
    files = [files, {'opt_pwc_yearly_GISTEMP_anom_with_sst_fine_1950-2016/'; 'opt_pwc_yearly_GISTEMP_anom_with_sst_fine'; '.mat'; ''; 'GISTEMP Processed, Land-Only + NOAA ERSST, Land + Ocean'; false; 'Anomalies'; 1950; 2016; 1950; true; -9999; -9999; 'PCF'}];
 
    files = [files, {'opt_pwc_yearly_grid_with_sst_coarse_1950-2016/'; 'opt_pwc_yearly_grid_with_sst_coarse'; '.mat'; ''; 'GISTEMP Processed Grid, Land-Ocean'; false; 'Anomalies'; 1950; 2016; 1950; true; -9999; -9999; 'PCC'}];
    files = [files, {'opt_pwc_yearly_GISTEMP_anom_with_sst_coarse_1950-2016/'; 'opt_pwc_yearly_GISTEMP_anom_with_sst_coarse'; '.mat'; ''; 'GISTEMP Processed, Land-Only + NOAA ERSST, Land + Ocean'; false; 'Anomalies'; 1950; 2016; 1950; true; -9999; -9999; 'PCC'}];
    

    for f_idx=1:size(files,2)

        % Get the range of years to be plotted
        start_year = files{8, f_idx};
        end_year = files{9, f_idx}; 
        n_years = end_year - start_year + 1;

        % Get the subset of each reference data set for the year range
        % NOTE: There is an assumed base year for these data sets
        noaa_land_sub = noaa_land_only(2, (start_year - 1880 + 1):(end_year - 1880 + 1));
        noaa_land_ocean_sub = noaa_land_ocean(2, (start_year - 1880 + 1):(end_year - 1880 + 1));
        nasa_land_sub = GIS_yearly_land_boxes.global_avg((start_year - 1880 + 1):(end_year - 1880 + 1))';
        nasa_land_ocean_sub = GIS_yearly_land_ocean_temps.global_avg((start_year - GIS_yearly_land_ocean_temps.first_year + 1):(end_year - GIS_yearly_land_ocean_temps.first_year + 1));

        % Load the data set
        data = load([path, files{1, f_idx}, files{2, f_idx}, files{3, f_idx}]);

        yearly_mu = zeros(n_years, 1);
        yearly_temps = zeros(n_years, 1);
        yearly_anoms = zeros(n_years, 1);
        num_empty_boxes = zeros(n_years, 1);

        % Get the mu, temperature and anomaly for each year
        for i=1:n_years

            var = ['data.', files{4, f_idx}, files{2, f_idx}, '{start_year - files{10, f_idx} + i}'];
            eval(['yearly_mu(i) = ',    var, '.mu / ' var '.scale;']);
            eval(['yearly_temps(i) = ', var, '.sval;']);
            eval(['yearly_anoms(i) = ', var, '.sanom;']);
            eval(['num_empty_boxes(i) = ', var, '.num_empty_boxes;']);

        end

        % Check if we are shifting the reference period
        if files{11, f_idx} 
            % shift the mean to the specified reference period
            start_ref_idx = 1951 - start_year + 1;
            end_ref_idx = 1980 - start_year + 1;
            m = mean(yearly_temps(start_ref_idx:end_ref_idx));
            yearly_anoms = yearly_temps - m;
        end

        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        % Data values
        plot(start_year:end_year, yearly_mu, 'LineWidth', 4);
        title(['\fontsize{12}', files{5, f_idx}, ', ', num2str(start_year), ' - ', num2str(end_year), ': \mu']);
        leg = legend({'\mu'}, 'Location', 'southeast');
        leg.FontSize = 12;
        box on;
        hold off;
        saveas(f, [path, files{2, f_idx}, '_', num2str(files{8, f_idx}), '-', num2str(files{9, f_idx}), '/', files{2, f_idx}, '_mu.png']);
        close(f);

        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        % Data values
        plot(start_year:end_year, yearly_temps, 'LineWidth', 4);
        %title(['\fontsize{12}', files{5, f_idx}, ', ', num2str(start_year), ' - ', num2str(end_year), ': ', files{7, f_idx}]);
        %leg = legend({['PWC: ', files{14, f_idx}]}, 'Location', 'southeast');
        leg = legend({[files{14, f_idx}]}, 'Location', 'southeast');
        leg.FontSize = 12;
        box on;
        hold off;
        saveas(f, [path, files{2, f_idx}, '_', num2str(files{8, f_idx}), '-', num2str(files{9, f_idx}), '/', files{2, f_idx}, '.png']);
        close(f);

        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        % Data values
        plot(start_year:end_year, yearly_anoms, 'LineWidth', 4);
        if files{6, f_idx}
            % NOAA land-only values
            plot(start_year:end_year, noaa_land_sub, 'LineWidth', 4);
            % NASA / GISS land-only values
            plot(start_year:end_year, nasa_land_sub, 'LineWidth', 4);
            %title(['\fontsize{12}', files{5, f_idx}, ', ', num2str(start_year), ' - ', num2str(end_year), ': Anomalies']);
            %leg = legend({['PWC: ', files{14, f_idx}], 'NOAA Land-only', 'NASA-GIS Land-only'}, 'Location', 'southeast');
            leg = legend({[files{14, f_idx}], 'NOAA', 'GISTEMP'}, 'Location', 'southeast');
            leg.FontSize = 12;
        else
            % NOAA land-only values
            plot(start_year:end_year, noaa_land_ocean_sub, 'LineWidth', 4);
            % NASA / GISS land-only values
            plot(start_year:end_year, nasa_land_ocean_sub, 'LineWidth', 4);
            %title(['\fontsize{12}', files{5, f_idx}, ', ', num2str(start_year), ' - ', num2str(end_year), ': Anomalies']);
            %leg = legend({['PWC: ', files{14, f_idx}], 'NOAA Land + Ocean', 'NASA-GIS Land + Ocean'}, 'Location', 'southeast');
            leg = legend({[files{14, f_idx}], 'NOAA', 'GISTEMP'}, 'Location', 'southeast');
            leg.FontSize = 12;
        end
        if files{12,f_idx} ~= -9999
            ylim([files{12, f_idx}, files{13, f_idx}]);
        end
        box on;
        hold off;
        if files{6, f_idx}
            saveas(f, [path, files{2, f_idx}, '_', num2str(files{8, f_idx}), '-', num2str(files{9, f_idx}), '/', files{2, f_idx}, '_Agency_TempAnom_land_only.png']);
        else
            saveas(f, [path, files{2, f_idx}, '_', num2str(files{8, f_idx}), '-', num2str(files{9, f_idx}), '/', files{2, f_idx}, '_Agency_TempAnom_land_ocean.png']);
        end
        close(f);
        
        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        % Number of empty boxes
        plot(start_year:end_year, num_empty_boxes, 'LineWidth', 4);
        title({['\fontsize{12}', files{5, f_idx}, ', ', num2str(start_year), ' - ', num2str(end_year), ': ', files{7, f_idx}], '\fontsize{10}Number of Empty Grid Cells'});
        %leg = legend({['Number of Empty Grid Cells: ', files{14, f_idx}]}, 'Location', 'southeast');
        %leg.FontSize = 12;
        if strcmp('fine', files{14, f_idx})
            ylim([0,8000]);
        else
            ylim([0, 80]);
        end
        box on;
        hold off;
        saveas(f, [path, files{2, f_idx}, '_', num2str(files{8, f_idx}), '-', num2str(files{9, f_idx}), '/', files{2, f_idx}, '_empty.png']);
        close(f);
    end
    

    
    
    
    
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    % files = [{<Path String>;
    %           <struct name>; 
    %           <filename suffix and extension>
    %           <plot title>
    %           <Region name>
    %           <reference data function call>
    %           <reference data base year>
    %           <anomaly plot y limit lower bound>
    %           <anomaly plot y limit upper bound>
    %           <anomaly plot x limit lower bound>
    %           <anomaly plot x limit upper bound>
    %         }, ... ];


    % Note that the winter reference data displays the year that the month 
    % of February fell upon.  The described winter is really from the 
    % previous year in the context of this code, and thus the reason 1895
    % is given as the reference data base year rather than 1896 that is 
    % shown in the data itself.  

    files = {};
    
    files = [files, {'region_texas_pwc_time_1950-2016/'; 'opt_pwc_time_summer_raw'; '.mat'; 'GHCND (Texas Only): Summer'; 'Texas'; 'noaa_texas_JJA_anomalies_base_1996_2015()'; 1895; -3; 3; 2000; 2016}];
    files = [files, {'region_texas_pwc_time_1950-2016/'; 'opt_pwc_time_winter_raw'; '.mat'; 'GHCND (Texas Only): Winter'; 'Texas'; 'noaa_texas_DJF_anomalies_base_1996_2015()'; 1895; -3; 3; 2000; 2016}];

    for f_idx=1:size(files,2)

        data = load([path, files{1, f_idx}, files{2, f_idx}, files{3, f_idx}]);

        % Get the range of years to be plotted
        start_year = data.start_year;
        end_year = data.end_year;
        n_years = end_year - start_year + 1;

        % Get the subset of each reference data set for the year range
        eval(['region_data = ', files{6, f_idx}, ';']);
        noaa_land_sub_temp = region_data(2, (start_year - files{7, f_idx} + 1):(end_year - files{7, f_idx} + 1));
        noaa_land_sub = region_data(3, (start_year - files{7, f_idx} + 1):(end_year - files{7, f_idx} + 1));
        
        % Find the maximum number of boxes that appeared in any year
        num_boxes = 0;
        for i=1:n_years
            var = 'data.res_cells{i}';
            eval(['num_boxes = max(num_boxes, ' var, '.num_boxes);']);
        end

        yearly_mu = zeros(n_years, 1);
        yearly_temps = zeros(n_years, 1);
        yearly_anoms = zeros(n_years, 1);
        num_empty_boxes = zeros(n_years, 1);

        % Get the mu and, temperature and number of empty cells for each year
        for i=1:n_years
            var = 'data.res_cells{i}';
            eval(['yearly_mu(i) = ',    var, '.mu;']);
            eval(['yearly_temps(i) = ', var, '.sval;']);
            eval(['all_empty = (', var, '.num_boxes == 0);']);
            if all_empty
                num_empty_boxes(i) = num_boxes;
            else
                eval(['num_empty_boxes(i) = ', var, '.num_empty_boxes;']);
            end
        end

        % shift the mean to the specified reference period
        % NOTE: The base start and end years are assumed here
        start_ref_idx = 1996 - start_year + 1;
        end_ref_idx = 2015 - start_year + 1;
        t_vals = yearly_temps(start_ref_idx:end_ref_idx);
        t_vals(isnan(t_vals)) = [];
        m = mean(t_vals);
        yearly_anoms = yearly_temps - m;

        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        % mu values
        plot(start_year:end_year, yearly_mu, 'LineWidth', 4);
        xlim([start_year, end_year]);
        title(['\fontsize{12}', files{4, f_idx}, ', ', num2str(start_year), ' - ', num2str(end_year), ': \mu']);
        leg = legend({'\mu'}, 'Location', 'southeast');
        leg.FontSize = 12;
        box on;
        hold off;
        saveas(f, [path, files{1, f_idx}, files{2, f_idx}, '_mu.png']);
        close(f);

        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        % temperature values
        plot(start_year:end_year, yearly_temps, 'LineWidth', 4);
        xlim([start_year, end_year]);
        title(['\fontsize{12}', files{4, f_idx}, ', ', num2str(start_year), ' - ', num2str(end_year), ': Temperature']);
        leg = legend({['PWC: ', files{5, f_idx}]}, 'Location', 'southeast');
        leg.FontSize = 12;
        box on;
        hold off;
        saveas(f, [path, files{1, f_idx}, files{2, f_idx}, '.png']);
        close(f);

        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        % temperature values
        plot(start_year:end_year, yearly_temps, 'LineWidth', 4);
        % NOAA land-only values
        plot(start_year:end_year, noaa_land_sub_temp, 'LineWidth', 4);
        xlim([start_year, end_year]);
        title(['\fontsize{12}', files{4, f_idx}, ', ', num2str(start_year), ' - ', num2str(end_year), ': Temperature']);
        leg = legend({['PWC: ', files{5, f_idx}], ['NOAA: ', files{5, f_idx}]}, 'Location', 'southeast');
        leg.FontSize = 12;
        box on;
        hold off;
        saveas(f, [path, files{1, f_idx}, files{2, f_idx}, '_Agency_Temp_land_only.png']);
        close(f);

        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        % anomaly values
        plot(start_year:end_year, yearly_anoms, 'LineWidth', 4);
        % NOAA land-only values
        plot(start_year:end_year, noaa_land_sub, 'LineWidth', 4);
        xlim([start_year, end_year]);
        %title(['\fontsize{12}', files{4, f_idx}, ', ', num2str(start_year), ' - ', num2str(end_year), ': Anomalies']);
        %leg = legend({['PWC: ', files{5, f_idx}], ['NOAA: ', files{5, f_idx}]}, 'Location', 'southeast');
        leg = legend({'PCF', 'NOAA'}, 'Location', 'southeast');
        leg.FontSize = 12;
        if files{8,f_idx} ~= -9999
            ylim([files{8, f_idx}, files{9, f_idx}]);
        end
        if files{10,f_idx} ~= -9999
            xlim([files{10, f_idx}, files{11, f_idx}]);
        end
        box on;
        hold off;
        saveas(f, [path, files{1, f_idx}, files{2, f_idx}, '_Agency_TempAnom_land_only.png']);
        close(f);
        
        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        % Number of empty boxes
        plot(start_year:end_year, num_empty_boxes, 'LineWidth', 4);
        xlim([start_year, end_year]);
        title({['\fontsize{12}', files{4, f_idx}, ', ', num2str(start_year), ' - ', num2str(end_year)], '\fontsize{10}Number of Empty Grid Cells'});
        ylim([0, num_boxes]);
        box on;
        hold off;
        saveas(f, [path, files{1, f_idx}, files{2, f_idx}, '_empty.png']);
        close(f);

    end




%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    % files = [{<Path String>;
    %           <struct name>; 
    %           <filename suffix and extension>
    %           <plot title>
    %           <plot start year>
    %           <plot end year>
    %           <data base year>
    %           <bool - true reshifts data to 1901-2000 reference period>
    %           <anomaly plot y limit lower bound>
    %           <anomaly plot y limit upper bound>
    %           <bool - convert mm to in>
    %         }, ... ];
    
    files = {};
    
    files = [files, {'opt_pwc_yearly_1901-2013/'; 'opt_pwc_yearly'; '.mat'; 'US Precipitation - Land-Only'; 1901; 2013; 1901; true; -9999; -9999; true; 'res_cells'}];

    for f_idx=1:size(files,2)

        % Get the range of years to be plotted
        start_year = files{5, f_idx}; 
        end_year = files{6, f_idx}; 
        n_years = end_year - start_year + 1;

        % Get the subset of each reference data set for the year range
        % NOTE: There is an assumed base year for these data sets
        %epa_prec = epa_precipitation_annual_anomalies_land_only();
        epa_prec = epa_precipitation_annual_anomalies_US_only();
        epa_prec_sub = epa_prec(2, (start_year - 1901 + 1):(end_year - 1901 + 1));

        

        % Load the data set 
        data = load([path, files{1, f_idx}, files{2, f_idx}, files{3, f_idx}]);

        yearly_mu = zeros(n_years, 1);
        yearly_precs = zeros(n_years, 1);
        yearly_anoms = zeros(n_years, 1);

        % Get the mu, prec and anomaly for each year
        for i=1:n_years

            var = ['data.', files{12, f_idx}, '{start_year - files{7, f_idx} + i}'];
            eval(['yearly_mu(i) = ',    var, '.mu / ' var '.scale;']);
            eval(['yearly_precs(i) = ', var, '.sval;']);
            eval(['yearly_anoms(i) = ', var, '.sanom;']);

        end
            
        % Check if we are converting the yearly precipitation to inches
        % from mm
        if files{11, f_idx}
            yearly_precs = convlength(yearly_precs / 1000, 'm', 'in');
            yearly_anoms = convlength(yearly_anoms / 1000, 'm', 'in');
        end

        % Check if we are shifting the reference period
        if files{8, f_idx} 
            % shift the mean to the specified reference period
            start_ref_idx = 1901 - start_year + 1;
            end_ref_idx = 2000 - start_year + 1;
            m = mean(yearly_precs(start_ref_idx:end_ref_idx));
            yearly_anoms = yearly_precs - m;
        end
            
        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        % mu values
        plot(start_year:end_year, yearly_mu, 'LineWidth', 4);
        title(['\fontsize{12}', files{4, f_idx}, ', ', num2str(start_year), ' - ', num2str(end_year), ': \mu']);
        leg = legend({'\mu'}, 'Location', 'southeast');
        leg.FontSize = 12;
        box on;
        hold off;
        saveas(f, [path, files{2, f_idx}, '_', num2str(files{5, f_idx}), '-', num2str(files{6, f_idx}), '/', files{2, f_idx}, '_mu.png']);
        close(f);

        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        % anomaly values
        plot(start_year:end_year, yearly_anoms, 'LineWidth', 4);
        % EPA land-only values
        plot(start_year:end_year, epa_prec_sub, 'LineWidth', 4);
        leg = legend({'PCF', 'EPA'}, 'Location', 'southeast');
        leg.FontSize = 12;
        if files{9, f_idx} ~= -9999
            ylim([files{9, f_idx}, files{10, f_idx}]);
        end
        box on;
        hold off;
        saveas(f, [path, files{2, f_idx}, '_', num2str(files{5, f_idx}), '-', num2str(files{6, f_idx}), '/', files{2, f_idx}, '_Agency_PrecAnom_land_only.png']);
        close(f);
        
    
        states = shaperead('usastatehi', 'UseGeoCoords', true,'Selector',{@(name) ~any(strcmp(name,{'Alaska','Hawaii'})), 'Name'});
        yr = 1985;
        yr_data = data.res_cells{yr-start_year+1};
        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        % US States
        geoshow(states, 'FaceColor', [1,1,1]);
        % 1x1 Grid locations
        plot(yr_data.longs, yr_data.lats, ...
            '.', ...
            'MarkerSize', 15, ...
            'MarkerEdgeColor', 'red', ...
            'MarkerFaceColor', 'red');
        box on;
        hold off;
        saveas(f, [path, files{2, f_idx}, '_', num2str(files{5, f_idx}), '-', num2str(files{6, f_idx}), '/', files{2, f_idx}, '_gpcc_us_grid_locations.png']);
        close(f);

        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        % US States
        geoshow(states, 'FaceColor', [1,1,1]);
        % Selected 1x1 Grid locations
        plot(yr_data.longs(yr_data.a > 0), yr_data.lats(yr_data.a > 0), ...
            '.', ...
            'MarkerSize', 15, ...
            'MarkerEdgeColor', 'red', ...
            'MarkerFaceColor', 'red');
        box on;
        hold off;
        saveas(f, [path, files{2, f_idx}, '_', num2str(files{5, f_idx}), '-', num2str(files{6, f_idx}), '/', files{2, f_idx}, '_gpcc_us_grid_locations_selected.png']);
        close(f);

    end

    
    
    
    
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    
    files = {};
    files = [files, {'opt_sh_yearly_GISTEMP_anom_with_sst_1950-2016/'; 'opt_sh_yearly_GISTEMP_anom_with_sst'; '.mat'; ''; 'GISTEMP Processed Stations, Land-Only + NOAA ERSST, Land + Ocean'; 1985; 1950}];

    L = 9;
    for f_idx=1:size(files,2)
        % Load the data set 
        data = load([path, files{1, f_idx}, files{2, f_idx}, '_L=', num2str(L), files{3, f_idx}]);
        
        year = files{6, f_idx}; 
        var = ['data.', files{4, f_idx}, files{2, f_idx}, '{year - files{7, f_idx} + 1}'];
        eval(['lats = ',   var, '.lats;']);
        eval(['longs = ',  var, '.longs;']);
        eval(['a = ',      var, '.a;']);
        
        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        geoshow('landareas.shp', 'FaceColor', 'white');
        plot (longs, lats, ...
            '.', ...
            'MarkerSize', 8, ...
            'MarkerEdgeColor', 'red', ...
            'MarkerFaceColor', 'red');
        %title(['\fontsize{12}', files{5, f_idx}, ' (', num2str(year), ')']);
        xlim([-180, 180]);
        ylim([-90, 90]);
        box on;
        hold off;
        saveas(f, [path, files{1, f_idx}, '/', files{2, f_idx}, '_locations_all_', num2str(files{6,f_idx}), '.png']);
        close(f);
        
        lats(a==0) = [];
        longs(a==0) = [];
        
        f = figure;
        set(f, 'position', [100, 500, 1024, 768]);
        hold on;
        geoshow('landareas.shp', 'FaceColor', 'white');
        plot (longs, lats, ...
            '.', ...
            'MarkerSize', 15, ...
            'MarkerEdgeColor', 'red', ...
            'MarkerFaceColor', 'red');
        %title(['\fontsize{12}', files{5, f_idx}, ', L = ', num2str(L), ' (', num2str(year), ')']);
        xlim([-180, 180]);
        ylim([-90, 90]);
        box on;
        hold off;
        saveas(f, [path, files{1, f_idx}, '/', files{2, f_idx}, '_locations_selected_', num2str(files{6,f_idx}), '_L=', num2str(L), '.png']);
        close(f);

    end
    
end
