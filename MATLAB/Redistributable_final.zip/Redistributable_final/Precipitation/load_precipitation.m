%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in February 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function prec_data = load_precipitation(filename)

    % Schneider, Udo; Becker, Andreas; Finger, Peter; Meyer-Christoffer, Anja; Rudolf, Bruno; Ziese, Markus (2011): GPCC Full Data Reanalysis Version 6.0 at 1.0°: Monthly Land-Surface Precipitation from Rain-Gauges built on GTS-based and Historic Data. DOI: 10.5676/DWD_GPCC/FD_M_V7_100

    %filename = 'GPCC/precip.mon.total.1x1.v7.nc';

    % Data is in mm

    monthly_accum = ncread(filename, 'precip');
    lats = ncread(filename, 'lat');
    longs = ncread(filename, 'lon');    
    
    if max(longs) > 180
        mask = longs > 180;
        longs(mask) = longs(mask) - 360;
    end
    
    missing_value = ncreadatt(filename, 'precip', 'missing_value');    
    monthly_accum(monthly_accum == missing_value) = -9999; % replace with our missing value
    
    n_months = size(monthly_accum,3);
    n_years = n_months / 12;
    if n_years ~= (2013 - 1901 + 1)
        error('Assumed number of years is incorrect');
    end
        
    monthly_accum = permute(monthly_accum, [2,1,3]);
    prec_data.monthly_accum = reshape(monthly_accum, 180*360, n_months);
    prec_data.lats = repmat(lats, 360,1);
    prec_data.longs = repelem(longs, 180,1);
    
    prec_data.yearly_accum = zeros(180*360, n_years);
    for idx=1:(180*360)
            
        for i=1:n_years
            y_data = prec_data.monthly_accum(idx, (12*(i-1)+1):(12*i));
            y_data(y_data == -9999) = [];
            if isempty(y_data)
                prec_data.yearly_accum(idx, i) = -9999;
            else
                prec_data.yearly_accum(idx, i) = sum(y_data);
            end
        end
        
    end        
    
    prec_data.start_year = 1901;
    prec_data.end_year = 2013;
    
end
