%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in February 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function valid_prec_data = find_valid_precip(prec_data, month, year)

    year_idx = year - prec_data.start_year + 1;
    
    valid_prec_data.month       = month;
    valid_prec_data.year        = year;

    % if the passed month is invalid (Jan = 1, ..., Dec = 12) then assume
    % the user wants yearly data
    if month > 0 && month < 13
        
        % find indices with valid data (invalid data marked with -9999)
        month_idx = (year_idx-1)*12 + month;
        indices = find(prec_data.monthly_accum(:, month_idx) ~= -9999);
        
        % return only monthly data
        valid_prec_data.monthly_accum = prec_data.monthly_accum(indices, month_idx);
        valid_prec_data.lats          = prec_data.lats(indices);
        valid_prec_data.longs         = prec_data.longs(indices);
    else
        
        % find indices with valid data (invalid data marked with -9999)
        indices = find(prec_data.yearly_accum(:,year_idx) ~= -9999);
        
        % return only yearly data        
        valid_prec_data.yearly_accum  = prec_data.yearly_accum(indices, year_idx);
        valid_prec_data.lats          = prec_data.lats(indices);
        valid_prec_data.longs         = prec_data.longs(indices);
    end

end
