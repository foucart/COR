%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in January 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Runs the piece-wise constant version of the optimization
%Input:
% inventory     - struct containing the station lats and longs, as well as
%                 the yearly temperature averages
% year          - The year from which the optimization will pull its data.
% use_fine_grid - True uses the 8000 subboxes from the Hansen grid, false
%                 uses only the 80 boxes from the Hansen grid.
%
%Output:
% a               - The weights computed by the optimization for each input
%                   station location and time
% mu              - The optimization value. mu / scale close to 1 is ideal.
% val             - The unscaled average temperature
% sval            - The scaled average temperature, sval = val / scale.  
%                   This is the value you want.
% scale           - The area of the occupied subboxes.
% M               - Number of staitons used
% lats            - The lats used by this optimization
% longs           - The longs used by this optimization
% num_boxes       - The total number of boxes in the grid
% num_empty_boxes - The number of unoccupied boxes
function [a, mu, val, sval, scale, M, lats, longs, num_boxes, num_empty_boxes] = grid_precip_pwc(inventory, year, use_fine_grid)

    lats = inventory.lats;
    longs = inventory.longs;

    data = inventory.yearly_accum(:,year - inventory.start_year + 1)';
    
    mask = data==-9999;
    data(mask) = [];
    lats(mask) = [];
    longs(mask) = [];
    
    M = length(lats);
    
    if use_fine_grid
        grid_boxes = GISTEMP_world_grid();
    else
        grid_boxes = GISTEMP_boxes80();
    end
    
    num_boxes = length(grid_boxes);

    B = zeros(num_boxes,M);
    c = zeros(num_boxes,1);
    
    cnt = zeros(num_boxes,1);
    
    earth_radius = 6375;
    
    % Rather than have a special case for the poles we use a naive contains
    % function and ensure that each station is used exactly once here.
    station_used = zeros(M,1);
    
    for row=1:num_boxes
        box = grid_boxes{row}; 
        tc = 0;
        for col=1:M
            
            if station_used(col)
                continue; %skip any station already claimed by a box - can introduce order dependence 
            end
            if contains(box, lats(col), longs(col))
                station_used(col) = 1;
                B(row,col) = 1;
                tc = tc + 1;
            %else
                %B(row,col) = 0; - the value is already zero
            end
        end 
        cnt(row) = tc;
        c(row, 1) = (pi/180) * earth_radius^2 * ...
                    abs(sind(box.lat_north)-sind(box.lat_south)) * ...
                    abs(box.lon_west-box.lon_east);
    end
    
    earth_area = sum(c); % ~510,100,000 km^2
    c = c / earth_area;
    
    % Remove empty rows - no stations in those subboxes
    B(~cnt,:) = [];
    c(~cnt) = [];
    num_empty_boxes = sum(cnt==0);
    
    disp(['  Attempting opt with ', num2str(M), ' locations and ', num2str(size(c,1)), ' grid locations']);
    
    %% optimization 
    cvx_solver gurobi
    cvx_quiet true %false

    tic;
        cvx_begin

        variable a(M)
        variable s(M)

        minimize sum(s)

        subject to
        s + a >= 0;
        s - a >= 0;
        B*a == c;

        cvx_end
    toc
    
    val = data*a;
    scale = sum(c);
    sval = val / scale;
    %disp(['a*data = ', num2str(val)]);
    
    %figure; 
    %plot(a); 
    %title(['a, L = ', num2str(L)]);
    
    mu = cvx_optval;
    
    %figure; 
    %scatter(longs(loc) * pi / 180, (lats(loc) + 90.0) * pi / 180.0, 5);
    %title('Selected Station Locations (from non-zero values in a)');
    

%     diary off;
end



%% Returns true if the passed lat,long is inside the passed box, false otherwise
% Note that locations falling on a boundary will be included on both sides
% of the boundary
function b = contains(box, lat, long)

    if lat > box.lat_north
        b = false;
        return;
    end
    if lat < box.lat_south
        b = false;
        return;
    end
    if long > box.lon_east
        b = false;
        return;
    end
    if long < box.lon_west
        b = false;
        return;
    end
    b = true;
   
end

%% If polarPref is false, then this returns true if the passed lat,long is
% within 1200km of the passed box center, false otherwise.  If polarPref is
% true then the boxes at the pole use the pole as teh box center - shared. 
% Note that this results in each subbox at the pole containing the same
% data.
function b = contains1200(box, s_lat, s_lon, polarPref)

    radius = 1200;
    earth_radius = 6375;
    arc = radius / earth_radius;
    
    [c_lat, c_lon] = box_center(box);
    if polarPref
        if round(c_lat) >= 84
            c_lat = 90;
            c_lon = 0;
        end
        if round(c_lat) <= -84
            c_lat = -90;
            c_lon = 0;
        end
    end
   
    cosarc = cos(arc);
    coslat = cosd(c_lat);
    sinlat = sind(c_lat);
    coslon = cosd(c_lon);
    sinlon = sind(c_lon);

    sinlats = sind(s_lat);
    coslats = cosd(s_lat);
    sinlons = sind(s_lon);
    coslons = cosd(s_lon);

    cosdi = (sinlats * sinlat + coslats * coslat * (coslons * coslon + sinlons * sinlon));

    b = cosdi > cosarc;
    %d = sqrt(2 * (1 - cosd));  % chord length on unit sphere
    %weight = 1.0 - (d / arc);
  
end
    





