%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in February 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Performs the summer and winter optimizations for the passed state station
% data.
% state_stations - the set of station data for a state in the US.
%                  = load_state_stations_daily_TAVG('TX');
% state          - String containing the name of the state for reporting
%                  only
function PWC_Time_Test(state_stations, state)

    start_year = 1950;
    end_year = 2016;
    ref_start_year = 1951;
    ref_end_year = 1980;
    
    path = ['Data/', 'region_', state, '_pwc_time_', ...
            num2str(start_year), '-', num2str(end_year), '/'];
        
    % load the region - replaced by state_stations
    %tx_stations = load_state_stations_daily_TAVG('TX');
    %tx_stations = load('tx_stations.mat');
    
    opt_pwc_time_summer_raw = run_opt(state_stations, true, ...
                                      start_year, end_year, ...
                                      ref_start_year, ref_end_year, ...
                                      path, 'opt_pwc_time_summer_raw');
    opt_pwc_time_winter_raw = run_opt(state_stations, false, ...
                                      start_year, end_year, ...
                                      ref_start_year, ref_end_year, ...
                                      path, 'opt_pwc_time_winter_raw');
    
end

function res_cells = run_opt(state_stations, use_summer, ...
                             start_year, end_year, ...
                             ref_start_year, ref_end_year, path, title)
    t = tic;
    
    n_years = end_year - start_year + 1;

    res_cells = cell(n_years,1);
    idx = 1;
    for year=start_year:end_year

        [res.a, res.mu, res.val, res.sval, res.scale, res.N, res.M,         ...
            res.lats, res.longs, res.num_boxes, res.num_stations,           ...
            res.num_empty_boxes] = ...
                pwc_time_region(state_stations, use_summer, year);
        res.year = year;

        disp([num2str(year), ': mu = ', num2str(res.mu)]);
        disp(['   temp = ', num2str(res.val)]);
        disp(['   temp (scaled) = ', num2str(res.sval)]);
        disp(['   number of boxes used: (', ...
             num2str(res.num_boxes - res.num_empty_boxes), ...
             ' out of ', num2str(res.num_boxes), ')']);
        disp(['   number of stations used: ', ...
             num2str(res.num_stations), ')']);
        save([path, title, '/opt_', num2str(year), '.mat'], 'res');

        res_cells{idx} = res;

        idx = idx + 1;
    end
    
    % find reference period mean
    s_idx = ref_start_year - start_year + 1;
    e_idx = ref_end_year - start_year + 1;
    ref_period = ref_end_year - ref_start_year + 1;
    ref_mean = 0;
    sref_mean = 0;
    for i = s_idx:e_idx
        ref_mean = ref_mean + res_cells{i}.val; 
        sref_mean = sref_mean + res_cells{i}.sval;
    end
    ref_mean = ref_mean / ref_period;
    sref_mean = sref_mean / ref_period;
    
    % convert temperature to anomalies from the reference period
    idx = 1;
    for year=start_year:end_year
        res_cells{idx}.ref_mean = ref_mean;
        res_cells{idx}.sref_mean = sref_mean;
        res_cells{idx}.anom = res_cells{idx}.val - ref_mean;
        res_cells{idx}.sanom = res_cells{idx}.sval - sref_mean;
        idx = idx + 1;
    end

    save([path, title, '.mat'], ...
                                'res_cells', ...
                                'start_year', ...
                                'end_year', ...
                                'ref_start_year', ...
                                'ref_end_year');
    toc(t);
   
end
