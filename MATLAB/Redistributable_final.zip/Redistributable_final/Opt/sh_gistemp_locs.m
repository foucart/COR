%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in January 2018
% with the assistance of S. Foucart
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Performs the optimization using spherical harmonics on the station data.
%Input:
% inventory - struct containing the station lats and longs, as well as the
%             yearly or monthly temperature averages
% month     - Jan = 1, ..., Dec = 12 for the month over which to compute
%             the global temperature for all years.  Or give any value not 
%             representing a month to compute annual averages instead.
% L         - The order of the spherical harmonics to use for the
%             optimization.
%
%Output:
% a     - The weights computed by the optimization for each input station
% mu    - The optimization value.  mu / scale close to 1 is ideal.
% val   - The unscaled average temperature
% sval  - The scaled average temperature, sval = val / scale.  This is the
%         value you want.
% scale - This value is 4pi for the spherical harmonics tests
% M     - The number of input stations
% lats  - The longs used by this optimization
% longs - The longs used by this optimization
function [a, mu, val, sval, scale, M, lats, longs] = sh_gistemp_locs(inventory, month, L)


    if month < 1 || month > 12
        if isfield(inventory, 'yearly_avg')
            data = inventory.yearly_avg;
        else
            data = inventory.yearly_accum;
        end
    else
        if isfield(inventory, 'monthly_avg')
            data = inventory.monthly_avg(month,:);
        else
            data = inventory.monthly_accum(month,:);
        end
    end
    
    
    lats = inventory.lats;
    longs = inventory.longs;
    M = length(lats);

    locations = zeros(2,M);
    % shift the latitude and longitude of all stations in the inventory for
    % the sh and convert to radians
    % latitude is in [-90, 90] and longitude is in [-180, 180]
    locations(1,:) = inventory.longs';
    locations(2,:) = inventory.lats' + 90.0;
    locations = locations * pi / 180;

    lambdaVec = locations(1,:);
    thetaVec = locations(2,:);

    %% create the matrix and vector in the constraints
    B = zeros((L+1)^2,M);
    c = zeros((L+1)^2,1);
    for l=0:L
        for m=-l:l  
            sh_lm = spherefun.sphharm(l,m);
            c(l^2+l+1+m,1) = sum2(sh_lm);
            idx = l^2+l+1+m;
            parfor j=1:M
               lambda = lambdaVec(j);%locations(1,j);
               theta = thetaVec(j);%locations(2,j);
               B(idx,j) = sh_lm(lambda,theta);
            end     
        end
    end
    
    %% optimization 

    cvx_solver gurobi
    cvx_quiet true %false

    tic;
        cvx_begin

        variable a(M)
        variable s(M)

        minimize sum(s)

        subject to
        s + a >= 0;
        s - a >= 0;
        B*a == c;

        cvx_end
    toc
    
    scale = 4*pi;
    %size(a(:))
    %size(data(:))
    val = dot(a(:),data(:));
    sval = val / scale;
    
    mu = cvx_optval; 
    

end
