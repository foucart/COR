%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in February 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


addpath('Precipitation');
addpath('GISTEMP');
addpath('Opt');
addpath('Agency');

% Range of years over which the opitimization(s) will occur
start_year     = 1901;
end_year       = 2013;
n_years        = end_year - start_year + 1;

% Reference year range used to compute anomalies from the temperature data
ref_start_year = 1901;
ref_end_year   = 2000;

local_path = 'Data/opt_pwc_yearly_1901-2013/';

prec_data = load_precipitation('GPCC/precip.mon.total.1x1.v7.nc');

%% Grab only the gridded data from the US (lower 48)
states = shaperead('usastatehi', 'UseGeoCoords', true,'Selector',{@(name) ~any(strcmp(name,{'Alaska','Hawaii'})), 'Name'});

lat_mask = zeros(size(prec_data.lats));

for i=1:49
    in = inpolygon(prec_data.longs, prec_data.lats, states(i).Lon, states(i).Lat);
    lat_mask = lat_mask + in;
end

lat_mask = (lat_mask > 0);

% geoshow(state, 'DefaultFaceColor','white', 'DefaultEdgeColor', 'red');
% hold on;
% scatter(prec_data.longs(lat_mask), prec_data.lats(lat_mask));

us_prec_data = prec_data;
us_prec_data.monthly_accum = us_prec_data.monthly_accum(lat_mask,:);
us_prec_data.lats = us_prec_data.lats(lat_mask);
us_prec_data.longs = us_prec_data.longs(lat_mask);
us_prec_data.yearly_accum = us_prec_data.yearly_accum(lat_mask,:);




%% 1 - Run optimization for V_{piecewise constant} at yearly resolution using 1x1 degree precipitation data (land-only data)

    % use precip.mon.total.1x1.v7.nc
    % run optimization independently for each year

    diary([local_path, 'opt_pwc_yearly.txt']);

    use_fine_grid = true;
    
    res_cells = cell(n_years,1);
    idx = 1;
    for year=start_year:end_year

        [res.a, res.mu, res.val, res.sval, res.scale, res.M,           ...
            res.lats, res.longs, res.num_boxes, res.num_empty_boxes] = ...
                grid_precip_pwc(us_prec_data, year, use_fine_grid);
        res.year = year;
        res.num_stations = res.M;

        disp([num2str(year), ': mu = ', num2str(res.mu)]);
        disp(['   precip = ', num2str(res.val)]);
        disp(['   precip (scaled) = ', num2str(res.sval)]);
        save([local_path, 'opt_pwc_yearly/opt_', num2str(year), '.mat'], 'res');

        res_cells{idx} = res;

        idx = idx + 1;
    end
    
    % find reference period mean
    s_idx = ref_start_year - start_year + 1;
    e_idx = ref_end_year - start_year + 1;
    ref_period = ref_end_year - ref_start_year + 1;
    ref_mean = 0;
    sref_mean = 0;
    for i = s_idx:e_idx
        ref_mean = ref_mean + res_cells{i}.val; 
        sref_mean = sref_mean + res_cells{i}.sval;
    end
    ref_mean = ref_mean / ref_period;
    sref_mean = sref_mean / ref_period;
    
    % convert temperature to anomalies from the reference period
    idx = 1;
    for year=start_year:end_year
        res_cells{idx}.ref_mean = ref_mean;
        res_cells{idx}.sref_mean = sref_mean;
        res_cells{idx}.anom = res_cells{idx}.val - ref_mean;
        res_cells{idx}.sanom = res_cells{idx}.sval - sref_mean;
        idx = idx + 1;
    end

    save([local_path, 'opt_pwc_yearly.mat'], ...
                                'res_cells', ...
                                'start_year', ...
                                'end_year', ...
                                'ref_start_year', ...
                                'ref_end_year');

                            
    diary off;

