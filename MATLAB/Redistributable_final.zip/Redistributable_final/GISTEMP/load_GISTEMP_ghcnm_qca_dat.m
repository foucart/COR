%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in October 2017
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function ghcnm_data = load_GISTEMP_ghcnm_qca_dat(filename)

% GISTEMP/gistemp1.0/tmp/input/ghcnm.tavg.qca.dat

    % id [1:11]
    % year [12:15]
    % element [16:19]

    % january [20:24]
    % february [28:32]
    % march [36:40]
    % april [44:48]
    % may [52:56]
    % june [60:64]
    % july [68:72]
    % august [76:80]
    % september [84:88]
    % october [92:96]
    % november [100:104]
    % december [108:112]
    
    fid = fopen(filename);
    if (fid < 0)
        error('File not found');
    end
    [bytes, num_bytes] = fread(fid, '*char');
    fclose(fid);

    num_entries = floor(num_bytes / 116); % 115 without newline

    ids = {num_entries};
    years = zeros(1, num_entries);
    monthly_avg = zeros(12, num_entries);
    yearly_avg = zeros(1, num_entries);
    
    num_with_data = 0;
    idx = 1;
    i = 1;
    while (i < num_bytes)

        % ID            1-11   Character
        ids{idx} = bytes(i:(i+10), 1)';
        i = i + 11;

        % Year          12-15    Integer
        years(1, idx) = str2double(bytes(i:(i+3), 1));
        i = i + 4;
        
        % element [16:19] - skip this as it is always TAVG
        i = i + 4;
        
        % january [20:24]
        monthly_avg(1, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % february [28:32]
        monthly_avg(2, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % march [36:40]
        monthly_avg(3, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % april [44:48]
        monthly_avg(4, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % may [52:56]
        monthly_avg(5, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % june [60:64]
        monthly_avg(6, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % july [68:72]
        monthly_avg(7, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % august [76:80]
        monthly_avg(8, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % september [84:88]
        monthly_avg(9, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % october [92:96]
        monthly_avg(10, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % november [100:104]
        monthly_avg(11, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % december [108:112]
        monthly_avg(12, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        i = i + 1;
        
        missing = monthly_avg(:,idx) == -9999;
        if sum(missing) == 12
            continue; % all months missing - do not increment idx or 
        end
        
        
        monthly_avg(~missing,idx) = monthly_avg(~missing,idx) / 100; % convert to C
        yearly_avg(idx) = mean(monthly_avg(~missing,idx));
 
        
        idx = idx + 1;
        num_with_data = num_with_data + 1;
    end
    
    ghcnm_data.ids = ids(1:num_with_data);
    ghcnm_data.years = years(1:num_with_data);
    ghcnm_data.monthly_avg = monthly_avg(:,1:num_with_data);
    ghcnm_data.yearly_avg = yearly_avg(1:num_with_data);
    
end
