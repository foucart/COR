%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in January 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function boxes = GISTEMP_boxes80()

    band_altitude = [1, 0.9, 0.7, 0.4, 0];
    band_boxes = [4, 8, 12, 16];
    
    boxes = {};
    box_idx = 1;
    % norther boxes
    for band=1:length(band_boxes)
        
        % number of horizontal boxes in band
        n = band_boxes(band);
        
        for idx=0:(n-1)

            box.lat_south = 180 / pi * real(asin(band_altitude(band + 1)));
            box.lat_north = 180 / pi * real(asin(band_altitude(band)));
            
            box.lon_west = -180 + 360 * idx / n;
            box.lon_east = -180 + 360 * (idx + 1) / n;
            
            boxes{box_idx} = box;
            box_idx = box_idx + 1;

        end
    end
    
    % southern boxes
    for band=1:length(band_boxes)
        
        % number of horizontal boxes in band
        n = band_boxes(band);
        
        for idx=0:(n-1)

            box.lat_north = -180 / pi * real(asin(band_altitude(band + 1)));
            box.lat_south = -180 / pi * real(asin(band_altitude(band)));
            
            box.lon_west = -180 + 360 * idx / n;
            box.lon_east = -180 + 360 * (idx + 1) / n;
            
            boxes{box_idx} = box;
            box_idx = box_idx + 1;

        end
    end
end
