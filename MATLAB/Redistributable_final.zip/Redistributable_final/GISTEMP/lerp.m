function v = lerp(x, y, p)
    v = y * p + (1 - p) * x;
end
