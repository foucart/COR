%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in January 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function merged = merge_GISTEMP_inv_data(inventory, temp_data)

    n = length(temp_data.ids);
    
    merged.ids = temp_data.ids;
    merged.years = temp_data.years;
    merged.monthly_avg = temp_data.monthly_avg;
    merged.yearly_avg = temp_data.yearly_avg;
    merged.lats = -9999 * ones(n,1);
    merged.longs = -9999 * ones(n,1);
    
    for i=1:n
        
        [~,c] = find(strcmp(inventory.ids, merged.ids(i)), 1);
        merged.names(i) = inventory.names(c);
        merged.lats(i) = inventory.lats(c);
        merged.longs(i) = inventory.longs(c);
    end
    
end
