%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in January 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function temp_averages = load_GISTEMP_step3_v3(filename)

% GISTEMP/gistemp1.0/tmp/work/step3.v3

    % box center lat [1:5]
    % box center long [6:11]
    % year [13:16]
    % element [17:20]

    % monthly anomalies in hundredths of a degree Celcius
    
    % january [21:25]
    % february [29:33]
    % march [37:41]
    % april [45:49]
    % may [53:57]
    % june [61:65]
    % july [69:73]
    % august [77:81]
    % september [85:89]
    % october [93:97]
    % november [101:105]
    % december [109:113]
    
    fid = fopen(filename);
    if (fid < 0)
        error('File not found');
    end
    [bytes, num_bytes] = fread(fid, '*char');
    fclose(fid);

    num_entries = floor(num_bytes / 117); % 116 without newline

    center_lats = zeros(1, num_entries);
    center_longs = zeros(1, num_entries);
    years = zeros(1, num_entries);
    monthly_anom = zeros(12, num_entries);
    yearly_anom = zeros(1, num_entries);
    
    num_with_data = 0;
    idx = 1;
    i = 1;
    while (i < num_bytes)
        
        % box center lat [1:5]
        center_lats(1,idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5;
        
        % box center long [6:11]
        center_longs(1,idx) = str2double(bytes(i:(i+5), 1));
        i = i + 6 + 1;

        % Year          13-16    Integer
        years(1, idx) = str2double(bytes(i:(i+3), 1));
        i = i + 4;
        
        % element [17:20] - skip this as it is always TAVG
        i = i + 4;
        
        % january [21:25]
        monthly_anom(1, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % february [29:33]
        monthly_anom(2, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % march [37:41]
        monthly_anom(3, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % april [45:49]
        monthly_anom(4, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % may [53:57]
        monthly_anom(5, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % june [61:65]
        monthly_anom(6, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % july [69:73]
        monthly_anom(7, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % august [77:81]
        monthly_anom(8, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % september [85:89]
        monthly_anom(9, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % october [93:97]
        monthly_anom(10, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % november [101:105]
        monthly_anom(11, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
        
        % december [109:113]
        monthly_anom(12, idx) = str2double(bytes(i:(i+4), 1));
        i = i + 5 + 3;
       
        i = i + 1;
        
        missing = monthly_anom(:,idx) == -9999;
        %if sum(missing) == 12
        if sum(missing) > 0
            continue; % months missing - do not increment idx 
        end
        
        
        monthly_anom(~missing,idx) = monthly_anom(~missing,idx) / 100; % convert to C
        yearly_anom(idx) = mean(monthly_anom(~missing,idx));

         
        idx = idx + 1;
        num_with_data = num_with_data + 1;
    end
    
    temp_averages.center_lats = center_lats(1:num_with_data);
    temp_averages.center_longs = center_longs(1:num_with_data);
    temp_averages.years = years(1:num_with_data);
    temp_averages.monthly_anom = monthly_anom(:,1:num_with_data);
    temp_averages.yearly_anom = yearly_anom(1:num_with_data);
    
end
