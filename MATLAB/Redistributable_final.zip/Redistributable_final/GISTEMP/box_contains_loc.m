%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in January 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function b = box_contains_loc(box, lat, long)

    if lat > box.lat_north
        b = false;
        return;
    end
    if lat < box.lat_south
        b = false;
        return;
    end
    if long > box.lon_east
        b = false;
        return;
    end
    if long < box.lon_west
        b = false;
        return;
    end
    b = true;
   
end
