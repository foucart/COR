%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in January 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function wg = GISTEMP_world_grid()

    boxes = GISTEMP_boxes80();
    
    wg = cell(8000,1);
    idx = 1;
    for b=1:length(boxes)
        box = boxes{b};
        wg(idx:(idx+100-1), 1) = GISTEMP_subbox100(box);
        idx = idx + 100;
    end
    
end
