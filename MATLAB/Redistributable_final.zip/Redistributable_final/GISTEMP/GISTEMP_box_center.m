%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in January 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [c_lat, c_lon] = GISTEMP_box_center(box)

    sinc = 0.5 * (sind(box.lat_south) + sind(box.lat_north));
    c_lat = real(asin(sinc)) * 180 / pi;
    c_lon = 0.5 * (box.lon_west + box.lon_east);
end
