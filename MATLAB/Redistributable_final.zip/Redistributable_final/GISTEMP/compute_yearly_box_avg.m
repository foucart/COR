%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in April 2017
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function yearly_boxes = compute_yearly_box_avg(boxes)

    yearly_boxes = boxes;

    num_years = boxes.last_year - boxes.first_year + 1;
    
    for idx = 1:size(boxes.box,2)
        
        yearly_boxes.box{idx}.yearly_avg = zeros(num_years, 1);
        
        for y = 1:num_years
            
            sum = 0;
            num = 0;

            for m = 1:12

                val = boxes.box{idx}.years(y,m);
                if val ~= boxes.missing_data_flag
                    sum = sum + val;
                    num = num + 1;
                end
                
            end
            
            if num > 0
                yearly_boxes.box{idx}.yearly_avg(y) = sum / num;
            else
                yearly_boxes.box{idx}.yearly_avg(y) = boxes.missing_data_flag;
            end
            
        end
    end
    
    yearly_boxes.global_avg = zeros(num_years, 1);
    
    for y = 1:num_years
        sum = 0;
        num = 0;
        
        for idx = 1:size(boxes.box,2)
            
            val = yearly_boxes.box{idx}.yearly_avg(y);
            
            if val ~= boxes.missing_data_flag
                w = boxes.box{idx}.weight;
                sum = sum + (w * val);
                num = num + w;
            end
            
        end
        
        if num > 0
            yearly_boxes.global_avg(y) = sum / num;
        else
            yearly_boxes.global_avg(y) = box.missing_data_flag;
        end
    end

end
