%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in January 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function subboxes = GISTEMP_subbox100(box)

    subboxes = cell(100,1);
    % Altitude for southern and northern border.
    alts = sind(box.lat_south);
    altn = sind(box.lat_north);
    idx = 1;
    for y=0:9
        s = 180 * real(asin(lerp(alts, altn, y * 0.1))) / pi;
        n = 180 * real(asin(lerp(alts, altn, (y + 1) * 0.1))) / pi;
        for x=0:9
            w = lerp(box.lon_west, box.lon_east, x * 0.1);
            e = lerp(box.lon_west, box.lon_east, (x + 1) * 0.1);
            
            subboxes{idx}.lat_south = s;
            subboxes{idx}.lat_north = n;
            subboxes{idx}.lon_west = w;
            subboxes{idx}.lon_east = e;
            idx = idx + 1;
        end
    end

end
      
