%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in January 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function valid_ssts = find_GISTEMP_valid_ssts(sbbx, month, year)

    valid_ssts.month = month;
    valid_ssts.year = year;
    
    valid_ssts.lats = [];
    valid_ssts.longs = [];
    
    if month > 0 && month < 13
        valid_ssts.monthly_avg = [];
    else
        valid_ssts.yearly_avg = [];
    end
    
    y_idx = year - 1880 + 1;
    m_offset = (y_idx-1) * 12 + 1;
    
    for i=1:length(sbbx.records)

        if sbbx.records{i}.station_months == 0
            continue; % subbox has no data - likely land
        end
        
        y_avg = sbbx.records{i}.yearly(y_idx);
        if abs(y_avg) == 9999
            continue; % no data for this year
        end
        
        m_avg = sbbx.records{i}.monthly(m_offset:(m_offset+11));

        if month > 0 && month < 13
            if abs(m_avg(month)) == 9999
                continue;
            end
            valid_ssts.monthly_avg = [valid_ssts.monthly_avg, m_avg];
        else
            valid_ssts.yearly_avg = [valid_ssts.yearly_avg, y_avg];
        end
        
        [c_lat, c_lon] = GISTEMP_box_center(sbbx.records{i}.box);
        
        valid_ssts.lats = [valid_ssts.lats, c_lat];
        valid_ssts.longs = [valid_ssts.longs, c_lon];

    end

end
