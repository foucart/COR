%% SF_simplex.m
% Finds a solution to the standard-form linear program
% minimize c'*x subject to A*x=b, x>=0
% using the simplex method initialized at a given index set

% Usage: [v,S] = SF_simplex(c,A,b,S0)
%
% c:  vector representing the linear objective function
% A:  matrix in the left-hand  side of the linear equality constraints 
% b:  vector in the right-hand side of the linear equality constraints
% S0: index set determining the initial vertex of the feasibility polytope  
%
% v: vertex of the feasibility polytope where the objective function is minimal
% S: index set associated with the vertex v
%
% Written by Simon Foucart in Sepember 2022
% Last updated in September 2022
% Send comments to simon.foucart@centraliens.net

function [v,S] = SF_simplex(c,A,b,S0)

[~,d] = size(A);
S = S0;
Sc = setdiff(1:d,S);
AS = A(:,S);
ASc = A(:,Sc);
v = zeros(d,1);
v(S) = AS\b;
certificate  = c(Sc) - ASc'*(AS'\c(S));
[~,i_aux] = min(certificate);
i = Sc(i_aux);
k = 0;
while certificate(i_aux)<0
   aux = AS\A(:,i);
   [~,j_aux] = min(v(S)./max(aux,0));
   j = S(j_aux);
   S = setdiff(S,j);
   S = sort([S; i]);
   Sc = setdiff(1:d,S);
   AS = A(:,S);
   ASc = A(:,Sc);
   v = zeros(d,1);
   v(S) = AS\b;
   certificate  = c(Sc) - ASc'*(AS'\c(S));
   [~,i_aux] = min(certificate);
   i = Sc(i_aux);
   k = k+1;
end

end