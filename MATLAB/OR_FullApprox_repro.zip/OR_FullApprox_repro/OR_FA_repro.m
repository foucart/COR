%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
%
% FULL RECOVERY FROM POINT VALUES:
% AN OPTIMAL ALGORITHM FOR CHEBYSHEV APPROXIMABILITY PRIOR
%
% by S. Foucart
%
% Reproducuble written by S. Foucart in September 2022
% Send comments to simon.foucart@centraliens.net
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Chebfun [2] is needed to run this reproducible
% mono.m, cheb.m, and lege.m create bases for V, in Chebfun format, 
% when V is the space of polynomials of degree <n
%
% the  external package CVX [3] can be used to solve the linear programs, 
% and so can the MATLAB function linprog (optimization toolbox required),
% alternatively, a custom implementation of the simplex algorithm
% is provided by SF_simplex.m 

clear all; clc;

%% 1. Optimal estimation in C[-1,1] from point evaluations 
%  of the linear functionals delta_x (point evaluations at x) 
%  for all x belonging to a fine grid on [-1,1] 

% preparation of the inputs for the optimization programs
n = 8;
basis_V = cheb(n);
m = 12;
eval_pts = linspace(-1,1,m) + [0, rand(1,m-2)/m, 0];
grid_size = 120;
grid = linspace(-1,1,grid_size);
M = zeros(n,m);
B = zeros(n,grid_size);
for j = 1:n
   M(j,:) = basis_V{j}(eval_pts);
   B(j,:) = basis_V{j}(grid);
end
% the matrix A will contain the minimizers a^sharp as its columns
% the matrix S will contain the supports of the minimizers as its columns 
A = zeros(m,grid_size);
S = zeros(n,grid_size);

%% To solve the optimization programs, choose CVX, linprog, or SF_simplex
% by uncommenting one of the following three options 

% using CVX --- no guarantee that the simplex algorithm is used

% tic;
% cvx_quiet true
% for k=1:grid_size
%     cvx_begin
%     variable a_p(m) nonnegative
%     variable a_m(m) nonnegative
%     minimize sum(a_p)+sum(a_m)
%     subject to
%     M*a_p - M*a_m == B(:,k);
%     cvx_end  
%     a = a_p-a_m;
%     A(:,k) = a;
%     [~,idx] = sort(abs(a),'descend');
%     S(:,k) = sort(idx(1:n));
% end
% toc

%% using linprog --- the simplex algorithm is likely used (no guarantee)

% options = optimoptions('linprog','Display','none');
% tic;
% for k=1:grid_size
%     [a_aux,~,~,output]=...
%         linprog(ones(2*m,1),[],[],[M,-M],B(:,k),zeros(2*m,1),inf(2*m,1),options);
%     a = a_aux(1:m)-a_aux(m+1:2*m);
%     A(:,k) = a;
%     [~,idx] = sort(abs(a),'descend');
%     S(:,k) = sort(idx(1:n));
% end
% toc

%% using SF_simplex --- note that an initial support S0 is required

tic;
for k=1:grid_size
    S0_aux = sort(randsample(m,n));
    v = M(:,S0_aux)\B(:,k);
    S0_p = S0_aux(v>0);
    S0_m = S0_aux(v<=0);
    S0 = [S0_p; S0_m+m];
    [a_aux,S_aux] = SF_simplex(ones(2*m,1),[M -M],B(:,k),S0);
    A(:,k) = a_aux(1:m)-a_aux(m+1:2*m);
    S(:,k) = sort([S_aux(S_aux<=n); S_aux(S_aux>n)-n]);
end
toc

%% Plot an ersatz optimal recovery map evaluated at some y, 
% i.e., plot a grid-approximation f_ersatz to Delta_sharp(y)

y = randn(m,1);
f_ersatz = zeros(1,grid_size);
for i=1:m
    f_ersatz = f_ersatz + y(i)*A(i,:);
end

figure(1);
plot(grid,f_ersatz,'r+')
pbaspect([2 1 1])
title('Ersatz optimal recovery map')
xlabel(strcat(sprintf('m=%d',m),sprintf(', n=%d',n)),'FontSize',16)
xline(eval_pts,'--k')

%% Now compute and plot a genuine optimal recovery map evaluated at the same y

a_sharp = full_rec(eval_pts,basis_V);
f_sharp = chebfun('0');
for i=1:m
    f_sharp = f_sharp + y(i)*a_sharp{i};
end
figure(2)
plot(f_sharp,'Linewidth',2)
pbaspect([2 1 1])
title('Genuine optimal recovery map')
xlabel(strcat(sprintf('m=%d',m),sprintf(', n=%d',n)),'FontSize',16)
xline(eval_pts,'--k')

%% Computation of the maximal ratio of uniform and discrete norms
% as the largest value of \|a^sharp(x)\|_1 over all x in [-1,1]
% to confirm the values obtained for equispaced points in [4] (Fig.9, 2nd row), 
% namely: m=21, n=11: about 2.5; m=41, n=21: about 15

m = 21; n = 11;
a_sharp = full_rec(linspace(-1,1,m),cheb(n));
res = chebfun('0');
for i=1:m
    res = res + abs(a_sharp{i});
end
max(res)
%
m = 41; n = 21;
a_sharp = full_rec(linspace(-1,1,m),cheb(n));
res = chebfun('0');
for i=1:m
    res = res + abs(a_sharp{i});
end
max(res)

%% Streaming data 
% comparison of the computation time for the above example done naively
% and for its warn-start version when inserting an evaluation point at 0

m = 41; n = 37;
eval_pts = linspace(-1,1,m) + [0, rand(1,m-2)/m, 0];

% naive starts
tic;
a_sharp_naive = full_rec(eval_pts,cheb(n));
t_naive = toc;

% warn starts
[~,S_aux] = full_rec([eval_pts(1:(m-1)/2) eval_pts((m-1)/2+2:end)],cheb(n));
% reindex by adding one to the second-half indices
for k=1:m-2
    SS = S_aux(:,k);
    S0_aux(:,k) = [SS(SS<=(m-1)/2); SS(SS>(m-1)/2)+1];
end
% split the central subinterval in two subintervals
S_central = S0_aux(:,(m-1)/2);
S_left = setdiff(S_central,(m-1)/2+2);
S_left = sort([S_left; (m-1)/2+1]);
S_right = setdiff(S_central,(m-1)/2);
S_right = sort([S_right; (m-1)/2+1]);
S0 = [S0_aux(:,1:(m-1)/2-1), S_left,...
    S_right, S0_aux(:,(m-1)/2+1:end)];
% perform the warm-start minimization
tic;
a_sharp_warm = full_rec(eval_pts,cheb(n),S0);
t_warm = toc; 


%% References
%
% 1. S. Foucart.
% "Full Recovery from Point Values:
%  an Optimal Algorithm for Chebyshev Approximability Prior",
% Preprint.
%
% 2. L. N. Trefethen et al., 
% "Chebfun Version 5, The Chebfun Development Team", 2014,
% http://www.chebfun.org.
%
% 3. CVX Research, Inc., 
% "CVX: MATLAB software for disciplined
% convex programming, version 2.1", 2014, http://cvxr.com/cvx.
%
% 4. B. Adcock, R. B. Platte, and A. Shadrin. 
% "Optimal sampling rates for approximating analytic functions from pointwise samples",
% IMA Journal of Numerical Analysis 39.3 (2019): 1360–1390.
