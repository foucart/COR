%% cheb.m
% Produces the Chebyshev basis for the space of algebraic polynomials of
% degree at most n-1

% Usage: basis = cheb(n)
%
% n: a positive integer representing the dimension of the polynomial space
%
% basis: a cell of chebfuns whose i-th element is the first-kind Chebyshev 
% polynomial of degree i-1 
%
% Written by Simon Foucart in March/April 2017
% Last updated in April 2017
% Send comments to simon.foucart@centraliens.net

function basis = cheb(n)

basis = cell(1,n);
for i = 1:n
    basis{i} = chebpoly(i-1);
end

end