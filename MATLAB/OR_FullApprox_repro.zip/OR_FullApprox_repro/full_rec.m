%% full_rec.m
% Produces the building-blocks of an optimal recovery map
% for the full recovery of a continous function 
% in an approximability model set involving a Chebyshev space
% and observed through point evaluations

% Usage: [a_sharp,S_sharp] = full_rec(eval_pts,basis_V,S0)
%
% eval_pts: a vector containing the evaluation points
% basis_V: a cell of chebfuns forming a basis for the Chebyshev space
% S0: a matrix whose columns contain the index sets used to initialize 
% the simplex algorithm (optional; the default is a random selection)
%  
% a_sharp: a cell of chebfuns whose i-th element represents the i-th entry 
% the function of x that outputs the i-th entry of the vector describing 
% the optimal estimation of the point evaluation at x in [-1,1]  
% Note: the optimal recovery map sends y to \sum_{i=1}^m y_i (a_sharp)_i 
% S_sharp: a matrix whose columns contain the supports that are common 
% to all L1-minimizers on each subinterval   
%
% Written by Simon Foucart in Sepember 2022
% Last updated in September 2022
% Send comments to simon.foucart@centraliens.net

function [a_sharp,S_sharp] = full_rec(eval_pts,basis_V,S0)

warning('Make sure that V contains the constant functions')

m = length(eval_pts);
n = length(basis_V);

if m < n
    error('number of evaluation points smaller than dimension of the space')
end
if n < 3
    error('the validity of the recovery procedure requires n > 2')
end

% check the evaluation points, sort them in a row, add -1 and 1 if needed
bk_pts = sort(reshape(eval_pts,1,m));
min_pts = bk_pts(1);
max_pts = bk_pts(m);
if min_pts < -1 || max_pts > 1
    error('evalutation points must belong to [-1,1]')
end
if min_pts > -1
    bk_pts = [-1, bk_pts];
end
if max_pts < 1
    bk_pts = [bk_pts, 1];
end
% create a point z^k in each of the K, say, subintervals
K = length(bk_pts)-1 ;
z = zeros(1,K);
for k = 1:K
    z(k) = (bk_pts(k)+bk_pts(k+1))/2;
end

% create the constraint matrix and the constraint vectors
M = zeros(n,m);
B = zeros(n,K);
for j = 1:n
   M(j,:) = basis_V{j}(eval_pts);
   B(j,:) = basis_V{j}(z);
end

% if needed, create initial supports for all the K subintervals
if nargin < 3
    for k = 1:K
        S0_aux = sort(randsample(m,n));
        v = M(:,S0_aux)\B(:,k);
        S0_pos = S0_aux(v>0);
        S0_neg = S0_aux(v<=0);
        S0(:,k) = [S0_pos; S0_neg+m];
    end
end

% preallocate tables (cell or matrices) for the outputs
a_sharp = cell(1,m);
for i=1:m
    a_sharp{i} = chebfun('0');
end
S_sharp = zeros(n,K);

% solve the L1-minimization programs (recast as K linear programs)
for k=1:K
    [a_aux,S_aux] = SF_simplex(ones(2*m,1),[M -M],B(:,k),S0(:,k));
    % construct the minimizer and support on the k-th subinterval
    a = a_aux(1:m)-a_aux(m+1:2*m);
    S = sort([S_aux(S_aux<=m); S_aux(S_aux>m)-m]);
    S_sharp(:,k) = S;
    % update the functions in a_sharp on the k-th subinterval
    indicator_k = ...
        chebfun(@(x) (x>bk_pts(k) & x<bk_pts(k+1)),[-1 1],'splitting','on');
    MS_inv = inv(M(:,S));
    for i=1:n
         aux = chebfun('0');
         for j=1:n
             aux = aux + MS_inv(i,j)*basis_V{j};
         end
         a_sharp{S(i)} = a_sharp{S(i)} + aux*indicator_k;
    end
end

end
