%% optapprox_C.m
% Produces a full approximation, based on evaluations at the given points,
% which is optimal relative to the space of continuous functions on [-1,1]
% and to the approximation space defined by the given basis functions

% Usage: funs = optapprox_C(pts,n,basisU,zeta)
%
% pts: the points where function evaluations are to take place
% n: a positive integer representing the dimension of the space V
% basisU: a basis for the superspace U of V (given as a cell of chebfuns)
% note: the first n elements of basisU must form a basis for V 
% zeta: the points upon which the underlying quasi-interpolant is built
%
% funs: the functions phi_j in the approximation sum_j f(pts(j)) phi_j to f
%       (returned as a cell of chebfuns)
%
% Written by Simon Foucart in March/April 2017
% Last updated in April 2017
% Send comments to simon.foucart@centraliens.net

function funs = optapprox_C(pts,n,basisU,zeta)

m = length(pts);
% if pts is a column vector, transform it in a row vector
if iscolumn(pts)
    pts = pts';
end
K = length(zeta);
% if zeta is a column vector, transform it in a row vector
if iscolumn(zeta)
    zeta = zeta';
end
N = length(basisU);

% define B
B = zeros(n,m);
for i=1:n
   B(i,:) = basisU{i}(pts); 
end

% define Z
Z = zeros(N,K);
for l=1:N
    Z(l,:) = basisU{l}(zeta);
end

% perform the minimization
cvx_quiet true
cvx_begin

variable A(m,N)
variable D(m,K)
variable c

minimize c

subject to
B*A == [eye(n) zeros(n,N-n)];
A*Z <= D;
A*Z >= -D;
sum(D) <= c;

cvx_end

% return the output
funs = cell(1,m);
for j=1:m
    psi_j = chebfun(0);
    for l=1:N
        psi_j = psi_j + A(j,l)*basisU{l};
    end
    funs{j} = psi_j;
end

end