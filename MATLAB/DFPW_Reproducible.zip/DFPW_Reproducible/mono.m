%% mono.m
% Produces the monomial basis for the space of algebraic polynomials of
% degree at most n-1

% Usage: basis = mono(n)
%
% n: a positive integer representing the dimension of the polynomial space
%
% basis: a cell of chebfuns whose i-th element is the i-th function in the
% monomial basis 
%
% Written by Simon Foucart in March/April 2017
% Last updated in April 2017
% Send comments to simon.foucart@centraliens.net


function basis = mono(n)

x = chebfun('x');
basis = cell(1,n);
for i = 1:n
    basis{i} = x.^(i-1);
end

end