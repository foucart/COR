%% opteval_C.m
% Produces a point evaluation, based on evaluations at other points,
% which is optimal relative to the space of continuous functions on [-1,1]
% and to the approximation space defined by the given basis functions

% Usage: [a_star,mu] = opteval_C(x,pts,basis)
%
% x: a point where one wishes to evaluate the function
% pts: the points where function evaluations are to take place
% basis: a basis for the approximation space V (given as a cell of chebfuns)
% note: a priori only valid if x is not one of the elements of pts
%
% a_star: the coefficient vector in the the formula
%         sum_i a_star(i) f(pts(i)) approximating the value of f at x        
% mu: the quantity mu(N_pts,V,delta_x)_C defined in the manuscript 
%
% Written by Simon Foucart in March/April 2017
% Last updated in April 2017
% Send comments to simon.foucart@centraliens.net

function [a_star,mu] = opteval_C(x,pts,basis)

n = length(basis);
m = length(pts);
% if pts is a column vector, transform it in a row vector
if iscolumn(pts)
    pts = pts';
end

% prepare the constraints for the optimization problem
B = zeros(n,m);
c = zeros(n,1);
for i = 1:n
   B(i,:) = basis{i}(pts);
   c(i) = basis{i}(x);
end

% perform the minimization (after recasting as a linear program)
cvx_quiet true
cvx_begin

variable a(m)
variable s(m)

minimize sum(s)

subject to
s - a >= 0;
s + a >= 0;
B*a == c;

cvx_end

a_star = a;
mu = 1 + cvx_optval;

end