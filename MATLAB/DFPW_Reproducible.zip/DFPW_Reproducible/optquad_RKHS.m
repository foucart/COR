%% optquad_RKHS.m
% Produces a quadrature formula, based on evaluations at the given points,
% which is optimal relative to a reproducing kernel Hilbert space
% and to the approximation space defined by the given basis functions

% Usage: [a_star,mu] = optquad_RKHS(pts,basis,kernel)
%
% pts: the points where function evaluations are to take place
% basis: a basis for the approximation space V (given as a cell of chebfuns)
% kernel: a bivariate function (given as a function handle)
%
% a_star: the coefficient vector in the quadrature formula 
%         sum_i a_star(i) f(pts(i)) approximating the integral of f         
% mu: the quantity mu(N_pts,V,integral)_RKHS defined in the manuscript 
%
% Written by Simon Foucart in March/April 2017
% Last updated in April 2017
% Send comments to simon.foucart@centraliens.net

function [a_star,mu] = optquad_RKHS(pts,basis,kernel)

n = length(basis);
m = length(pts);
% if pts is a column vector, transform it in a row vector
if iscolumn(pts)
    pts = pts';
end

% define the matrix B and the vector c
B = zeros(n,m);
c = zeros(n,1);
for i = 1:n
   B(i,:) = basis{i}(pts);
   c(i) = sum(basis{i});
end

% define P (and P^(1/2))
P = zeros(m,m);
for i = 1:m
    for j = 1:m
        P(i,j) = kernel(pts(i),pts(j));
    end
end
sqrtP = sqrtm(P);

% define y
h = zeros(m,1);
for i = 1:m
   hi  = @(x) kernel(pts(i),x);
   h(i) = integral(hi,-1,1);
end
y = sqrt(P)\h;

% solution of the minimization problem --- see paper for details
a_bar = B\c;
[Q,~] = qr(B');
Q2 = Q(:,n+1:m);
z_star = (sqrtP*Q2) \ (y-sqrtP*a_bar);

% return the outputs
a_star = a_bar + Q2*(z_star);                    % this is the minimizer
mu = sqrt(integral2(kernel,-1,1,-1,1)-norm(y)^2 + norm(y-sqrtP*a_star)^2);

end