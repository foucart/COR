%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% COMPUTING A QUANTITY OF INTEREST FROM OBSERVATIONAL DATA
% by R. DeVore, S. Foucart, G. Petrova, P. Wojtaszczyk
% Written by S. Foucart in March/April 2017
% with the assistance of Matthew Hielsberg
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% CVX [2] and Chebfun [3] are needed to run this reproducible 
% external functions: basis = mono(n)
%                     basis = cheb(n)
%                     basis = lege(n)


%% 1. Integral approximation from point evaluations in C[-1,1] %%
% external function: [a_star,mu] = optquad_C(pts,basis)
%---------------------------------------------------------------%

%% Small-scale example for random points 
% when the approximation space V is a polynomial space

n = 5;                                  % the dimension of V
m = 12;                                 % number of points
rdpts = sort(2*rand(1,m)-1);            % random points in [-1,1]

% in this generic situation, the minimizer should (often) be unique,
% in particular, it should not depend on the basis chosen for V
% (possible choices: monomial, Chebyshev, or Legendre basis)

[a1,mu1] = optquad_C(rdpts,mono(n));
[a2,mu2] = optquad_C(rdpts,cheb(n));
[a3,mu3] = optquad_C(rdpts,lege(n));

disp(strcat(...
    'The three minimizers are similar: ',...
    sprintf('\n the euclidean distance between the first and the second is %d ', norm(a1-a2)),...
    sprintf('\n the euclidean distance betweem the first and the third is %d', norm(a1-a3))))
disp(' ')

%% Small-scale example for equispaced points 
% when the approximation space V is a polynomial space

n = 5;                                  % the dimension of V
m = 12;                                 % number of points
eqpts = linspace(-1,1,m);               % equispaced points in [-1,1]

% in this situation, the minimizer is not unique,
% in particular, it may depend on the solver chosen for CVX
% (possible choices with standard CVX: sedumi, sdpt3, 
% and with an academic/professional license: mosek, gurobi)

cvx_solver sedumi
[a1,mu1] = optquad_C(eqpts,mono(n));
cvx_solver sdpt3
[a2,mu2] = optquad_C(eqpts,mono(n));
cvx_solver mosek
[a3,mu3] = optquad_C(eqpts,mono(n));
cvx_solver gurobi
[a4,mu4] = optquad_C(eqpts,mono(n));

disp(strcat('The minimizers are different: ',...
    sprintf('\n e.g. the euclidean distance between the first and the third is %d ', norm(a1-a3)),...
    sprintf('\nThe first and second minimizers are full: '),...
    sprintf('\n the numbers of nonzero entries are %d ', length(find(abs(a1)>1e-5)) ),...
    sprintf(' and %d', length(find(abs(a2)>1e-5))),...
    sprintf('\nwhile the third and fourth minimizers are sparse: '),...
    sprintf('\n the numbers of nonzero entries are %d ', length(find(abs(a3)>1e-5)) ),...
    sprintf(' and %d', length(find(abs(a4)>1e-5))) ))
disp(' ')

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% THE RECOMMANDATION IS TO USE THE SOLVER MOSEK OR GUROBI,
% OR SDPT3 IF AN ACADEMIC/PROFESSIONAL LICENSE IS NOT AVAILABLE 
% AND TO USE THE CHEBYSHEV OR THE LEGENDRE BASIS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Rationale for the recommanded choices
% For larger scale examples, the results depend significantly on the chosen
% basis and solver.  Which output should be trusted?
% We base our decision on some theoretical work of Wilson, see [4].
% A rephrasing of Theorem 2.1 there shows that,
% if m <= ((n+2)/2/pi)^2+1  (n even)
% or m <= ((n+1)/2/pi)^2+1  (n odd)
% then the m equispaced points cannot provide a quadrature formula
% with nonnegative weights that reproduces polynomials of degree n-1,
% in other words they cannot yield constant mu equal to 4

n = 70;
m = floor( (n+1)^2/4/pi^2 + 1 );
eqpts = linspace(-1,1,m); 

cvx_solver gurobi
[a1,mu1] = optquad_C(eqpts,mono(n));    
[a2,mu2] = optquad_C(eqpts,cheb(n));
[a3,mu3] = optquad_C(eqpts,lege(n));
disp(['The monomial basis should be rejected, because mu = ', num2str(mu1)])

cvx_solver sedumi
[a4,mu4] = optquad_C(eqpts,cheb(n));
cvx_solver sdpt3
[a5,mu5] = optquad_C(eqpts,cheb(n));
cvx_solver mosek
[a6,mu6] = optquad_C(eqpts,cheb(n));
cvx_solver gurobi
[a7,mu7] = optquad_C(eqpts,cheb(n));
disp(strcat(sprintf('SeDuMi is not advised, because mu = %d', mu4),...
    ' with the Chebyshev basis'))

cvx_solver sedumi
[a8,mu8] = optquad_C(eqpts,lege(n));
cvx_solver sdpt3
[a9,mu9] = optquad_C(eqpts,lege(n));
cvx_solver mosek
[a10,mu10] = optquad_C(eqpts,lege(n));
cvx_solver gurobi
[a11,mu11] = optquad_C(eqpts,lege(n));
disp(strcat(sprintf('Again, SeDuMi gives mu = %d', mu8),...
    ' with the Legendre basis'))
disp(' ')


%% Nonnegative quadrature formulas exact on P_{n-1} based on equispaced points of [-1,1]
% Explore the frontier in the (n,m)-plane 
% between the regions of existence and nonexistence of such formulas, 
% i.e., between the regions where mu=4 and mu>4
% The values of mu (and the corresponding optimal quadrature formulas)
% have been precomputed and stored in the files QUADFLA_xx-10.bin
% with xx=1,11,21,31,...,151
% They are found in the subfolder supplement (if downladed) 
% See gen_quad_fla_sparse.m for the code that generated these files

cd supplement

n_max = 160;
Wilson_lower = (((1:n_max)+1)/2/pi).^2;
Wilson_upper = (1:n_max).^2;
m_star = zeros(1,n_max);
mu = load_all_quad_fla_sparse(cd,1,n_max);
for n=1:n_max
    [~,idx] = find_first_min_mu(mu{n},4);
    m_star(n) = idx+n-1;
end
% fix a minor aberration
m_star(106) = m_star(105);

figure(1)
plot(1:n_max,Wilson_lower,'b--',1:n_max,m_star,'r-',1:n_max,Wilson_upper,'g-.','LineWidth',2)
legend('lower bound', 'true transition', 'upper bound','Location','northwest')
xlabel('n','FontSize',16)
ylabel('m_*(n)','FontSize',16)
title('When do nonnegative quadrature formulas exist?','FontSize',16)
pbaspect([3 1 1])

cd ..


%% Algorithm performance on a given function (not too smooth)
% e.g. f(x) = |sin(x)| has integral over [-1,1] equal to 2*(1-cos(1)) = 0.9194
% as a function of the dimension n of the polynomial approximation space

m = 45;                                  % number of data points
eqpts = linspace(-1,1,m);                % equispaced points in [-1,1]

data = abs(sin(eqpts));                  % the data f(tau_1),...,f(tau_n)

% the integration error as a function of n
err = zeros(1,m);
cvx_solver gurobi
for n = 1:m
    % coefs of the optimal quadrature exact on P_{n-1}
    [a_star,~] = optquad_C(eqpts,cheb(n));   
    % error between the quadrature value and the true integral
    err(n) = abs( data*a_star - 2*(1-cos(1)) );
end
% the plot of the error as a function of n
figure(2);
subplot(1,2,1); plot(1:m,err)
xlabel('n','FontSize',16)
ylabel('error(n)','FontSize',16)
pbaspect([1 1 1])
title('It may be beneficial...','FontSize',16)
subplot(1,2,2); plot(5:m-14,err(5:m-14))
xlabel('n','FontSize',16)
ylabel('error(n)','FontSize',16)
pbaspect([1 1 1])
title('...to take n smaller than m','FontSize',16)


%% 2. Integral approximation from point evaluations in a RKHS  %%
% external function: [a_star,mu] = optquad_RKHS(pts,basis,kernel)
%---------------------------------------------------------------%


%% Example for equispaced points when the RKHS is the anchored Sobolev space
% and the approximation space V is a polynomial space

clear all; clc;

n = 60;                         % the dimension of V
m = 150;                        % number of points
eqpts = linspace(-1,1,m);       % equispaced points in [-1,1]
kernel_AS = @(x,y) 2+min(x,y);  % the kernel of the anchored Sobolev space

[a1,mu1] = optquad_RKHS(eqpts,mono(n),kernel_AS);
[a2,mu2] = optquad_RKHS(eqpts,cheb(n),kernel_AS);
[a3,mu3] = optquad_RKHS(eqpts,lege(n),kernel_AS);

disp(strcat( 'There still appears to be a problem with the momonial basis: ',...
    sprintf('\n it yields the value mu='), num2str(mu1), ...
    sprintf('\n while the Chebyshev and Legendre bases yield the values mu= '), ...
    num2str(mu2), ' and mu= ', num2str(mu3) ))


%%    3. Full approximation from point evaluations in C[-1,1]      %%
% external functions: [funs,optval] = optapprox_C(pts,n,basisU,zeta)
%                     [a_star,mu] = opteval_C(x,pts,basis)
%-------------------------------------------------------------------%

%% Small-scale example showing the atom-functions involved in the "optimal" algorithm
% for equispaced points when the approximation space V is a polynomial space

clear all; clc;
cvx_solver gurobi

n = 5;
basisV = cheb(n);
m = 12;
eqpts = linspace(-1,1,m);
grid_size = 300;
grid = linspace(-1,1,grid_size);
A = zeros(m,grid_size);
for j = 1:grid_size
    A(:,j) = opteval_C(grid(j),eqpts,basisV);
end

figure(3); 
plot(eqpts,zeros(1,m),'ko');
pbaspect([2 1 1])
title(strcat(sprintf('m=%d',m),sprintf(', n=%d',n)),'FontSize',16)
hold on;
cmap = colormap(jet(m));
linestyles = {'-', '--', ':', '-.'};
for i=1:m,
    plot(grid,A(i,:),'LineStyle', linestyles{rem(i-1,numel(linestyles))+1},...
        'Color', cmap(i,:),'LineWidth',2);
end 

%% Same example for a "near-optimal" algorithm

n = 5;
N = 25;
basisU = cheb(N);
K = 50;
zeta = chebpts(K);
m = 12;
eqpts = linspace(-1,1,m);
funs = optapprox_C(eqpts,n,basisU,zeta);

figure(4);
plot(eqpts,zeros(1,m),'ko');
pbaspect([2 1 1])
title(strcat(sprintf('m=%d',m),sprintf(', n=%d',n),sprintf(' , N=%d',N),...
    sprintf(' , K=%d',K)),'FontSize',16)
hold on;
cmap = colormap(jet(m));
linestyles = {'-', '--', ':', '-.'};
for i=1:m
    plot(funs{i},'LineStyle', linestyles{rem(i-1,numel(linestyles))+1},...
    'Color',cmap(i,:),'LineWidth',2); 
end


%% Performance of the algorithms on a given function (not too smooth)
% e.g. f(x) = |sin(x)|

% we use the same values for m, n, N, K as in the previous two examples

x = chebfun('x'); f = abs(sin(x));     % the function to be approximated
data = f(eqpts);                       % the values of f at equispaced points
f_star = remez(f,n);                   % the true best approximant to f from P_{n-1}

% the full approximation from the data which is optimal relative to P_{n-1}
% discritize on the grid
opt_approx = A'*data';

% the full approximation from the data which is near-optimal relative to P_{n-1}
nearopt_approx = chebfun(0);
for i=1:m
    nearopt_approx = nearopt_approx + data(i)*funs{i};
end

figure(5); 
subplot(1,2,1); 
plot(grid,f(grid),'k', grid,opt_approx,'r','LineWidth',2);
xlabel(strcat('Optimal algorithm: ', sprintf(' m=%d',m),sprintf(', n=%d',n)),'FontSize',16)
ylabel(strcat('max error on grid = ', num2str(max(abs(f(grid)'-opt_approx)))),...
    'FontSize',16)
legend('original function f','approximation of f from data')
title(strcat('with true best approximant, max error on grid = ',...
   num2str(max(abs(f(grid)-f_star(grid))))))
%legend(strcat('max error on grid=', num2str(max(abs(f(grid)'-opt_approx)))))
subplot(1,2,2); 
plot(grid,f(grid),'k', grid,nearopt_approx(grid),'g','LineWidth',2);
xlabel(strcat('Near-optimal algorithm: ',sprintf(' m=%d',m),sprintf(', n=%d',n),...
    sprintf(' , N=%d',N),sprintf(' , K=%d',K)),'FontSize',16)
ylabel(strcat('max error on grid=', num2str(max(abs(f(grid)-nearopt_approx(grid))))),...
    'FontSize',16)
legend('original function f','approximation of f from data')
title(strcat('with true best approximant, max error on grid =',...
   num2str(max(abs(f(grid)-f_star(grid))))))


%% References
%
% 1. R. DeVore, S. Foucart, G. Petrova, P. Wojtaszczyk, 
% "Computing a quantity of interest from observational data",
% Preprint.
%
% 2. CVX Research, Inc., 
% "CVX: MATLAB software for disciplined
% convex programming, version 2.1", 2014, http://cvxr.com/cvx.
%
% 3. L. N. Trefethen et al., 
% "Chebfun Version 5, The Chebfun Development Team", 2014,
% http://www.chebfun.org.
%
% 4. M. W. Wilson, 
% "Necessary and sufficient conditions for equidistant quadrature formila",
% SIAM J. NUmer. Anal., 7(1), 134--141, 1970.