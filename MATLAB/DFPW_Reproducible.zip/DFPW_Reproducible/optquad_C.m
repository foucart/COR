%% optquad_C.m
% Produces a quadrature formula, based on evaluations at the given points,
% which is optimal relative to the space of continuous functions on [-1,1]
% and to the approximation space defined by the given basis functions

% Usage: [a_star,mu] = optquad_C(pts,basis)
%
% pts: the points where function evaluations are to take place
% basis: a basis for the approximation space V (given as a cell of chebfuns)
%
% a_star: the coefficient vector in the quadrature formula 
%         sum_i a_star(i) f(pts(i)) approximating the integral of f         
% mu: the quantity mu(N_pts,V,integral)_C defined in the manuscript 
%
% Written by Simon Foucart in March/April 2017
% Last updated in April 2017
% Send comments to simon.foucart@centraliens.net

function [a_star,mu] = optquad_C(pts,basis)

n = length(basis);
m = length(pts);
% if pts is a column vector, transform it in a row vector
if iscolumn(pts)
    pts = pts';
end

% prepare the constraints for the optimization problem
B = zeros(n,m);
c = zeros(n,1);
for i = 1:n
   B(i,:) = basis{i}(pts);
   c(i) = sum(basis{i});
end

% perform the minimization (after recasting it as a linear program)
cvx_quiet true
cvx_begin

variable a(m)
variable s(m)

minimize sum(s)

subject to
s - a >= 0;
s + a >= 0;
B*a == c;

cvx_end

a_star = a;
mu = 2 + cvx_optval;

end